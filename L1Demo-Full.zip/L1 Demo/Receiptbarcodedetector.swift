//
//  Receiptbarcodedetector.swift
//  L1 Demo
//
//  Created by Derek Punaro on 12/13/25.
//

import UIKit
import Vision

// MARK: - Barcode Detection Errors
enum BarcodeDetectionError: LocalizedError {
    case invalidImage
    case detectionFailed(Error)
    case noBarcodeFound
    
    var errorDescription: String? {
        switch self {
        case .invalidImage:
            return "Invalid image provided for barcode detection"
        case .detectionFailed(let error):
            return "Barcode detection failed: \(error.localizedDescription)"
        case .noBarcodeFound:
            return "No barcode found in image"
        }
    }
}

/// Detects barcodes in receipt images using Apple's Vision framework
final class ReceiptBarcodeDetector {
    
    // MARK: - Configuration
    private static let supportedSymbologies: [VNBarcodeSymbology] = [
        .code128,
        .code39,
        .code93,
        .ean13,
        .ean8,
        .upce,
        .pdf417,
        .qr,
        .dataMatrix,
        .i2of5
    ]
    
    // MARK: - Barcode Detection
    
    /// Detect barcode in the given image
    /// - Parameter image: UIImage to scan for barcodes
    /// - Returns: The barcode value as a string, or nil if no barcode found
    static func detectBarcode(in image: UIImage) async throws -> String? {
        guard let cgImage = image.cgImage else {
            throw BarcodeDetectionError.invalidImage
        }
        
        return try await withCheckedThrowingContinuation { continuation in
            let request = VNDetectBarcodesRequest { request, error in
                if let error = error {
                    continuation.resume(throwing: BarcodeDetectionError.detectionFailed(error))
                    return
                }
                
                // Get the first barcode result
                guard let results = request.results as? [VNBarcodeObservation],
                      let firstBarcode = results.first,
                      let payload = firstBarcode.payloadStringValue else {
                    continuation.resume(returning: nil)
                    return
                }
                
                continuation.resume(returning: payload)
            }
            
            // Configure to detect common receipt barcode types
            request.symbologies = supportedSymbologies
            
            let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
            
            do {
                try handler.perform([request])
            } catch {
                continuation.resume(throwing: BarcodeDetectionError.detectionFailed(error))
            }
        }
    }
    
    /// Detect all barcodes in the given image
    /// - Parameter image: UIImage to scan for barcodes
    /// - Returns: Array of barcode values found
    static func detectAllBarcodes(in image: UIImage) async throws -> [String] {
        guard let cgImage = image.cgImage else {
            throw BarcodeDetectionError.invalidImage
        }
        
        return try await withCheckedThrowingContinuation { continuation in
            let request = VNDetectBarcodesRequest { request, error in
                if let error = error {
                    continuation.resume(throwing: BarcodeDetectionError.detectionFailed(error))
                    return
                }
                
                guard let results = request.results as? [VNBarcodeObservation] else {
                    continuation.resume(returning: [])
                    return
                }
                
                let barcodes = results.compactMap { $0.payloadStringValue }
                continuation.resume(returning: barcodes)
            }
            
            request.symbologies = supportedSymbologies
            
            let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
            
            do {
                try handler.perform([request])
            } catch {
                continuation.resume(throwing: BarcodeDetectionError.detectionFailed(error))
            }
        }
    }
}
