//
//  ReceiptCameraView.swift
//  L1 Demo
//
//  ENHANCED: Real-time receipt detection with Vision framework
//  Shows green outline when receipt is detected
//  Auto-crops to receipt bounds on capture
//
//  FIX: Removed duplicate capture paths that caused double saves
//

import SwiftUI
import AVFoundation
import Vision

// MARK: - Constants
private enum CameraConstants {
    static let sessionQueueLabel = "camera.session.queue"
    static let detectionQueueLabel = "receipt.detection.queue"
    static let flashFeedbackOpacity: Double = 0.3
    static let flashFeedbackDuration: TimeInterval = 0.1
}

// MARK: - Detected Rectangle
struct DetectedRectangle: Equatable {
    let topLeft: CGPoint
    let topRight: CGPoint
    let bottomLeft: CGPoint
    let bottomRight: CGPoint
    let boundingBox: CGRect
    let confidence: Float
    
    /// Convert Vision coordinates to view coordinates
    func toViewCoordinates(in size: CGSize) -> DetectedRectangle {
        // Vision uses bottom-left origin, SwiftUI uses top-left
        // Also need to flip Y coordinates
        return DetectedRectangle(
            topLeft: CGPoint(x: topLeft.x * size.width, y: (1 - topLeft.y) * size.height),
            topRight: CGPoint(x: topRight.x * size.width, y: (1 - topRight.y) * size.height),
            bottomLeft: CGPoint(x: bottomLeft.x * size.width, y: (1 - bottomLeft.y) * size.height),
            bottomRight: CGPoint(x: bottomRight.x * size.width, y: (1 - bottomRight.y) * size.height),
            boundingBox: CGRect(
                x: boundingBox.minX * size.width,
                y: (1 - boundingBox.maxY) * size.height,
                width: boundingBox.width * size.width,
                height: boundingBox.height * size.height
            ),
            confidence: confidence
        )
    }
}

// MARK: - Photo Capture Delegate

private class PhotoCaptureDelegate: NSObject, AVCapturePhotoCaptureDelegate {
    private weak var cameraManager: CameraManager?
    private let completion: (UIImage?) -> Void
    
    init(cameraManager: CameraManager, completion: @escaping (UIImage?) -> Void) {
        self.cameraManager = cameraManager
        self.completion = completion
    }
    
    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        defer {
            DispatchQueue.main.async {
                self.cameraManager?.isCapturing = false
            }
        }
        
        if let error = error {
            print("❌ Photo capture error: \(error)")
            completion(nil)
            return
        }
        
        guard let data = photo.fileDataRepresentation(),
              let image = UIImage(data: data) else {
            print("❌ Could not create image from photo data")
            completion(nil)
            return
        }
        
        // Fix orientation
        let fixedImage = image.fixedOrientation()
        
        // Try to crop to detected receipt
        if let croppedImage = ReceiptCropper.cropToReceipt(fixedImage) {
            print("✅ Cropped to receipt bounds")
            completion(croppedImage)
        } else {
            print("ℹ️ Using full image (no receipt detected)")
            completion(fixedImage)
        }
    }
}

// MARK: - Receipt Cropper

enum ReceiptCropper {
    /// Crop image to detected receipt bounds
    static func cropToReceipt(_ image: UIImage) -> UIImage? {
        guard let cgImage = image.cgImage else { return nil }
        
        let request = VNDetectRectanglesRequest()
        request.minimumAspectRatio = 0.2   // Receipts are tall and narrow
        request.maximumAspectRatio = 0.8
        request.minimumSize = 0.15          // At least 15% of image
        request.minimumConfidence = 0.6
        request.maximumObservations = 1
        
        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        
        do {
            try handler.perform([request])
            
            guard let observation = request.results?.first else {
                return nil
            }
            
            // Get the four corners of the detected rectangle
            let topLeft = observation.topLeft
            let topRight = observation.topRight
            let bottomLeft = observation.bottomLeft
            let bottomRight = observation.bottomRight
            
            // Convert to image coordinates
            let imageWidth = CGFloat(cgImage.width)
            let imageHeight = CGFloat(cgImage.height)
            
            // Use bounding box for simple crop (perspective correction would be more complex)
            let bbox = observation.boundingBox
            let cropRect = CGRect(
                x: bbox.minX * imageWidth,
                y: (1 - bbox.maxY) * imageHeight,
                width: bbox.width * imageWidth,
                height: bbox.height * imageHeight
            )
            
            // Add some padding
            let padding: CGFloat = 10
            let paddedRect = cropRect.insetBy(dx: -padding, dy: -padding)
            
            // Ensure rect is within bounds
            let clampedRect = paddedRect.intersection(CGRect(x: 0, y: 0, width: imageWidth, height: imageHeight))
            
            guard let croppedCGImage = cgImage.cropping(to: clampedRect) else {
                return nil
            }
            
            return UIImage(cgImage: croppedCGImage, scale: image.scale, orientation: image.imageOrientation)
            
        } catch {
            print("❌ Receipt crop failed: \(error)")
            return nil
        }
    }
}

// MARK: - Receipt Camera View

struct ReceiptCameraView: View {
    let onPhotoCaptured: (UIImage) -> Void
    let onCancel: () -> Void
    
    @StateObject private var cameraManager = CameraManager()
    @State private var showingPermissionAlert = false
    @State private var hasDeliveredImage = false  // Guard against duplicate delivery
    
    var body: some View {
        ZStack {
            // Camera preview
            CameraPreviewView(session: cameraManager.session)
                .ignoresSafeArea()
            
            // Receipt detection overlay
            GeometryReader { geometry in
                ZStack {
                    // Detected rectangle overlay
                    if let rect = cameraManager.detectedRectangle {
                        let viewRect = rect.toViewCoordinates(in: geometry.size)
                        
                        // Draw the detected rectangle with corner points
                        Path { path in
                            path.move(to: viewRect.topLeft)
                            path.addLine(to: viewRect.topRight)
                            path.addLine(to: viewRect.bottomRight)
                            path.addLine(to: viewRect.bottomLeft)
                            path.closeSubpath()
                        }
                        .stroke(Color.green, lineWidth: 3)
                        
                        // Corner indicators
                        ForEach([viewRect.topLeft, viewRect.topRight, viewRect.bottomLeft, viewRect.bottomRight], id: \.x) { corner in
                            Circle()
                                .fill(Color.green)
                                .frame(width: 12, height: 12)
                                .position(corner)
                        }
                    } else {
                        // Static guide when no receipt detected
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(Color.white.opacity(0.5), lineWidth: 2)
                            .frame(width: geometry.size.width * 0.85, height: geometry.size.height * 0.7)
                    }
                }
            }
            
            // Overlay UI
            VStack {
                // Top bar
                topBar
                
                Spacer()
                
                // Detection status
                detectionStatus
                
                Spacer()
                
                // Bottom controls
                bottomControls
            }
            
            // Flash feedback
            if cameraManager.isCapturing {
                Color.white
                    .ignoresSafeArea()
                    .opacity(CameraConstants.flashFeedbackOpacity)
                    .animation(.easeOut(duration: CameraConstants.flashFeedbackDuration), value: cameraManager.isCapturing)
            }
        }
        .onAppear {
            hasDeliveredImage = false
            checkCameraPermission()
        }
        .onDisappear {
            cameraManager.stop()
        }
        .alert("Camera Access Required", isPresented: $showingPermissionAlert) {
            Button("Open Settings") {
                if let url = URL(string: UIApplication.openSettingsURLString) {
                    UIApplication.shared.open(url)
                }
            }
            Button("Cancel", role: .cancel) {
                onCancel()
            }
        } message: {
            Text("Please allow camera access in Settings to capture receipts.")
        }
    }
    
    // MARK: - Subviews
    
    private var topBar: some View {
        HStack {
            Button {
                onCancel()
            } label: {
                Image(systemName: "xmark")
                    .font(.title2)
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.black.opacity(0.5))
                    .clipShape(Circle())
            }
            
            Spacer()
            
            // Detection indicator
            HStack(spacing: 6) {
                Circle()
                    .fill(cameraManager.detectedRectangle != nil ? Color.green : Color.gray)
                    .frame(width: 10, height: 10)
                Text(cameraManager.detectedRectangle != nil ? "Receipt Detected" : "Scanning...")
                    .font(.caption)
                    .foregroundColor(.white)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(Color.black.opacity(0.6))
            .cornerRadius(20)
            
            Spacer()
            
            // Flash toggle
            Button {
                cameraManager.toggleFlash()
            } label: {
                Image(systemName: cameraManager.flashMode == .on ? "bolt.fill" : "bolt.slash.fill")
                    .font(.title2)
                    .foregroundColor(cameraManager.flashMode == .on ? .yellow : .white)
                    .padding()
                    .background(Color.black.opacity(0.5))
                    .clipShape(Circle())
            }
        }
        .padding()
    }
    
    private var detectionStatus: some View {
        VStack(spacing: 8) {
            if cameraManager.detectedRectangle != nil {
                Label("Receipt found - Tap to capture", systemImage: "checkmark.circle.fill")
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .foregroundColor(.white)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 10)
                    .background(Color.green.opacity(0.85))
                    .cornerRadius(25)
            } else {
                VStack(spacing: 4) {
                    Text("Point camera at receipt")
                        .font(.subheadline)
                        .foregroundColor(.white)
                    Text("Hold steady for detection")
                        .font(.caption)
                        .foregroundColor(.white.opacity(0.7))
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 10)
                .background(Color.black.opacity(0.6))
                .cornerRadius(12)
            }
        }
    }
    
    private var bottomControls: some View {
        HStack(spacing: 60) {
            // Placeholder for symmetry
            Color.clear
                .frame(width: 50, height: 50)
            
            // Capture button
            Button {
                capturePhoto()
            } label: {
                ZStack {
                    // Outer ring - green when detected
                    Circle()
                        .stroke(cameraManager.detectedRectangle != nil ? Color.green : Color.white, lineWidth: 4)
                        .frame(width: 80, height: 80)
                    
                    // Inner circle
                    Circle()
                        .fill(Color.white)
                        .frame(width: 70, height: 70)
                    
                    // Checkmark when detected
                    if cameraManager.detectedRectangle != nil {
                        Image(systemName: "checkmark")
                            .font(.title)
                            .fontWeight(.bold)
                            .foregroundColor(.green)
                    }
                }
            }
            .disabled(cameraManager.isCapturing || hasDeliveredImage)
            .opacity(hasDeliveredImage ? 0.5 : 1.0)
            .scaleEffect(cameraManager.detectedRectangle != nil ? 1.05 : 1.0)
            .animation(.easeInOut(duration: 0.2), value: cameraManager.detectedRectangle != nil)
            
            // Placeholder for symmetry
            Color.clear
                .frame(width: 50, height: 50)
        }
        .padding(.bottom, 40)
    }
    
    // MARK: - Capture Logic (Single Path)
    
    private func capturePhoto() {
        // Guard against double-tap and duplicate delivery
        guard !cameraManager.isCapturing, !hasDeliveredImage else {
            print("⚠️ Capture blocked: isCapturing=\(cameraManager.isCapturing), hasDelivered=\(hasDeliveredImage)")
            return
        }
        
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
        
        cameraManager.capturePhoto { [self] image in
            // Ensure we only deliver once
            guard !hasDeliveredImage else {
                print("⚠️ Image already delivered, ignoring duplicate")
                return
            }
            
            if let image = image {
                hasDeliveredImage = true
                onPhotoCaptured(image)
            }
        }
    }
    
    // MARK: - Permissions
    
    private func checkCameraPermission() {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            cameraManager.start()
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { granted in
                DispatchQueue.main.async {
                    if granted {
                        cameraManager.start()
                    } else {
                        showingPermissionAlert = true
                    }
                }
            }
        case .denied, .restricted:
            showingPermissionAlert = true
        @unknown default:
            showingPermissionAlert = true
        }
    }
}

// MARK: - Camera Manager with Rectangle Detection

final class CameraManager: NSObject, ObservableObject {
    @Published var isCapturing = false
    @Published var flashMode: AVCaptureDevice.FlashMode = .auto
    @Published var detectedRectangle: DetectedRectangle?
    
    let session = AVCaptureSession()
    private let photoOutput = AVCapturePhotoOutput()
    private let videoOutput = AVCaptureVideoDataOutput()
    private var device: AVCaptureDevice?
    private let sessionQueue = DispatchQueue(label: CameraConstants.sessionQueueLabel)
    private let detectionQueue = DispatchQueue(label: CameraConstants.detectionQueueLabel, qos: .userInitiated)
    private var currentPhotoCaptureDelegate: PhotoCaptureDelegate?
    
    // Rectangle detection request
    private lazy var rectangleRequest: VNDetectRectanglesRequest = {
        let request = VNDetectRectanglesRequest { [weak self] request, error in
            self?.handleRectangleDetection(request: request, error: error)
        }
        request.minimumAspectRatio = 0.2    // Receipts are tall and narrow
        request.maximumAspectRatio = 0.85
        request.minimumSize = 0.15           // At least 15% of frame
        request.minimumConfidence = 0.6
        request.maximumObservations = 1
        return request
    }()
    
    // Throttle detection to avoid overwhelming
    private var lastDetectionTime: Date = .distantPast
    private let detectionInterval: TimeInterval = 0.1  // 10 FPS for detection
    
    override init() {
        super.init()
        setupSession()
    }
    
    private func setupSession() {
        sessionQueue.async { [weak self] in
            guard let self = self else { return }
            
            self.session.beginConfiguration()
            self.session.sessionPreset = .high  // Changed from .photo for video output
            
            // Find back camera
            guard let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) else {
                print("❌ No back camera available")
                self.session.commitConfiguration()
                return
            }
            
            self.device = device
            
            // Configure device
            do {
                try device.lockForConfiguration()
                
                if device.isFocusModeSupported(.continuousAutoFocus) {
                    device.focusMode = .continuousAutoFocus
                }
                
                if device.isExposureModeSupported(.continuousAutoExposure) {
                    device.exposureMode = .continuousAutoExposure
                }
                
                device.unlockForConfiguration()
            } catch {
                print("⚠️ Could not configure camera: \(error)")
            }
            
            // Add input
            do {
                let input = try AVCaptureDeviceInput(device: device)
                if self.session.canAddInput(input) {
                    self.session.addInput(input)
                }
            } catch {
                print("❌ Could not create camera input: \(error)")
                self.session.commitConfiguration()
                return
            }
            
            // Add photo output
            if self.session.canAddOutput(self.photoOutput) {
                self.session.addOutput(self.photoOutput)
                self.photoOutput.isHighResolutionCaptureEnabled = true
                if self.photoOutput.maxPhotoQualityPrioritization != .speed {
                    self.photoOutput.maxPhotoQualityPrioritization = .quality
                }
            }
            
            // Add video output for real-time detection
            if self.session.canAddOutput(self.videoOutput) {
                self.session.addOutput(self.videoOutput)
                self.videoOutput.setSampleBufferDelegate(self, queue: self.detectionQueue)
                self.videoOutput.alwaysDiscardsLateVideoFrames = true
                
                // Set pixel format
                if let connection = self.videoOutput.connection(with: .video) {
                    connection.videoOrientation = .portrait
                }
            }
            
            self.session.commitConfiguration()
        }
    }
    
    func start() {
        sessionQueue.async { [weak self] in
            guard let self = self, !self.session.isRunning else { return }
            self.session.startRunning()
        }
    }
    
    func stop() {
        sessionQueue.async { [weak self] in
            guard let self = self, self.session.isRunning else { return }
            self.session.stopRunning()
        }
    }
    
    func toggleFlash() {
        switch flashMode {
        case .auto:
            flashMode = .on
        case .on:
            flashMode = .off
        case .off:
            flashMode = .auto
        @unknown default:
            flashMode = .auto
        }
    }
    
    func capturePhoto(completion: @escaping (UIImage?) -> Void) {
        // Double-check we're not already capturing
        guard !isCapturing else {
            print("⚠️ CameraManager: Already capturing, ignoring request")
            return
        }
        
        DispatchQueue.main.async {
            self.isCapturing = true
        }
        
        sessionQueue.async { [weak self] in
            guard let self = self else { return }
            
            let settings = AVCapturePhotoSettings()
            
            if self.photoOutput.supportedFlashModes.contains(self.flashMode) {
                settings.flashMode = self.flashMode
            }
            
            settings.isHighResolutionPhotoEnabled = true
            
            // Create delegate - completion is the ONLY path for image delivery
            let delegate = PhotoCaptureDelegate(cameraManager: self, completion: completion)
            
            // Hold strong reference until capture completes
            self.currentPhotoCaptureDelegate = delegate
            self.photoOutput.capturePhoto(with: settings, delegate: delegate)
        }
    }
    
    private func handleRectangleDetection(request: VNRequest, error: Error?) {
        if let error = error {
            print("⚠️ Rectangle detection error: \(error.localizedDescription)")
            return
        }
        
        guard let observations = request.results as? [VNRectangleObservation],
              let observation = observations.first else {
            // No rectangle detected
            DispatchQueue.main.async {
                self.detectedRectangle = nil
            }
            return
        }
        
        let detected = DetectedRectangle(
            topLeft: observation.topLeft,
            topRight: observation.topRight,
            bottomLeft: observation.bottomLeft,
            bottomRight: observation.bottomRight,
            boundingBox: observation.boundingBox,
            confidence: observation.confidence
        )
        
        DispatchQueue.main.async {
            self.detectedRectangle = detected
        }
    }
}

// MARK: - Video Frame Processing for Detection

extension CameraManager: AVCaptureVideoDataOutputSampleBufferDelegate {
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        // Throttle detection
        let now = Date()
        guard now.timeIntervalSince(lastDetectionTime) >= detectionInterval else { return }
        lastDetectionTime = now
        
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        
        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .right, options: [:])
        
        do {
            try handler.perform([rectangleRequest])
        } catch {
            print("⚠️ Vision request failed: \(error)")
        }
    }
}

// MARK: - Camera Preview View

struct CameraPreviewView: UIViewRepresentable {
    let session: AVCaptureSession
    
    func makeUIView(context: Context) -> CameraPreviewUIView {
        let view = CameraPreviewUIView()
        view.session = session
        return view
    }
    
    func updateUIView(_ uiView: CameraPreviewUIView, context: Context) {}
}

final class CameraPreviewUIView: UIView {
    var session: AVCaptureSession? {
        didSet {
            guard let session = session else { return }
            previewLayer.session = session
        }
    }
    
    private var previewLayer: AVCaptureVideoPreviewLayer {
        layer as! AVCaptureVideoPreviewLayer
    }
    
    override class var layerClass: AnyClass {
        AVCaptureVideoPreviewLayer.self
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupLayer()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupLayer()
    }
    
    private func setupLayer() {
        previewLayer.videoGravity = .resizeAspectFill
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        if let connection = previewLayer.connection {
            let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene
            let orientation = windowScene?.interfaceOrientation ?? .portrait
            
            let videoOrientation: AVCaptureVideoOrientation
            switch orientation {
            case .portrait:
                videoOrientation = .portrait
            case .portraitUpsideDown:
                videoOrientation = .portraitUpsideDown
            case .landscapeLeft:
                videoOrientation = .landscapeLeft
            case .landscapeRight:
                videoOrientation = .landscapeRight
            default:
                videoOrientation = .portrait
            }
            
            if connection.isVideoOrientationSupported {
                connection.videoOrientation = videoOrientation
            }
        }
    }
}

// MARK: - UIImage Orientation Fix

extension UIImage {
    func fixedOrientation() -> UIImage {
        guard imageOrientation != .up else { return self }
        
        UIGraphicsBeginImageContextWithOptions(size, false, scale)
        draw(in: CGRect(origin: .zero, size: size))
        let normalizedImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return normalizedImage ?? self
    }
}

// MARK: - Preview

#Preview {
    ReceiptCameraView(
        onPhotoCaptured: { _ in },
        onCancel: { }
    )
}
