// Item.swift
// Refactored Version - Fixed Thread Safety Issues
// All SwiftData access is main-thread only (enforced by @Model macro)

import Foundation
import SwiftData
import UIKit

@Model
final class ReceiptItem {
    var id: UUID
    var barcodeValue: String?
    var timestamp: Date
    var storeName: String?
    var purchaseDate: Date?
    var totalAmount: Double?
    var rawText: String?
    @Attribute(.externalStorage) var imageData: Data?
    
    // MARK: - Success Tracking
    var autoFilledFields: [String] = [] // Stores keys like "register", "member", "items", "barcode"
    
    // Calculates a 0-100 score based on data quality
    var reliabilityScore: Double {
        var score: Double = 0
        if barcodeValue != nil { score += 0.3 }
        if memberID != nil { score += 0.2 }
        if let count = expectedItemCount, count > 0 { score += 0.5 }
        return score
    }

    init(barcodeValue: String? = nil, /* ... other params ... */) {
        self.id = UUID()
        self.barcodeValue = barcodeValue
        self.timestamp = Date()
        self.autoFilledFields = []
    }
    // MARK: - Costco-specific parsed fields
    var cashierNumber: String?
    var registerNumber: String?
    var transactionNumber: String?
    var memberID: String?
    var expectedItemCount: Int?

    // MARK: - Audit Fields (NEW - for persistence)
    var auditItemOvercharge: String?
    var auditOverchargeName: String?
    var auditOverchargeCost: String?
    var auditItemUndercharge: String?
    var auditUnderchargeName: String?
    var auditUnderchargeCost: String?
    var auditBob: Bool = false
    var auditThreeTotal: Bool = false
    var auditPrescan: Bool = false
    var auditPrescanMatchesBasket: Bool = false
    var auditSecurity: String?
    var auditCashier: String?
    var auditAssistant: String?
    var auditSupervisor: String?
    var auditWeek: String?
    var auditCompleted: Bool = false  // Track if audit was completed
    var auditCompletedDate: Date?     // When audit was completed
    
    // MARK: - Items stored as JSON Data (avoids CoreData Array issues)
    var itemsData: Data? {
        didSet {
            // Invalidate cache only when data actually changes
            if itemsData != oldValue {
                _cachedItems = nil
            }
        }
    }
    
    var detailedItemsData: Data? {
        didSet {
            if detailedItemsData != oldValue {
                _cachedDetailedItems = nil
            }
        }
    }
    
    // MARK: - Cache Properties
    // Note: SwiftData @Model enforces main-thread access, no need for manual thread checks
    
    @Transient private var _cachedUIImage: UIImage?
    @Transient private var _cachedFormattedDate: String?
    @Transient private var _cachedFormattedTotal: String?
    @Transient private var _cachedItems: [String]?
    @Transient private var _cachedDetailedItems: [StoredLineItem]?

    init(barcodeValue: String) {
        self.id = UUID()
        self.barcodeValue = barcodeValue
        self.timestamp = Date()
    }

    init(imageData: Data, rawText: String) {
        self.id = UUID()
        self.imageData = imageData
        self.rawText = rawText
        self.timestamp = Date()
    }
    
    // MARK: - Items Accessor (simple string array)
    
    var items: [String]? {
        get {
            // Return cached if available
            if let cached = _cachedItems {
                return cached
            }
            
            // Decode from JSON data
            guard let data = itemsData else { return nil }
            let decoded = try? JSONDecoder().decode([String].self, from: data)
            _cachedItems = decoded
            return decoded
        }
        set {
            // Update cache and data
            _cachedItems = newValue
            if let newValue = newValue {
                itemsData = try? JSONEncoder().encode(newValue)
            } else {
                itemsData = nil
            }
        }
    }
    
    // MARK: - Detailed Items Accessor
    
    var detailedItems: [StoredLineItem] {
        get {
            // Return cached if available
            if let cached = _cachedDetailedItems {
                return cached
            }
            
            // Decode from JSON data
            guard let data = detailedItemsData else { return [] }
            let decoded = (try? JSONDecoder().decode([StoredLineItem].self, from: data)) ?? []
            _cachedDetailedItems = decoded
            return decoded
        }
        set {
            // Update cache and data
            _cachedDetailedItems = newValue
            detailedItemsData = try? JSONEncoder().encode(newValue)
        }
    }

    // MARK: - Formatted Values with Caching
    
    /// Cached formatted total
    var formattedTotal: String {
        if let cached = _cachedFormattedTotal {
            return cached
        }
        
        guard let total = totalAmount else { return "N/A" }
        let formatted = String(format: "$%.2f", total)
        _cachedFormattedTotal = formatted
        return formatted
    }

    /// Lazy image loading with caching
    var uiImage: UIImage? {
        if let cached = _cachedUIImage {
            return cached
        }
        
        guard let imageData = imageData else { return nil }
        let image = UIImage(data: imageData)
        _cachedUIImage = image
        return image
    }
    
    /// Thumbnail generation for list views (smaller memory footprint)
    func thumbnail(size: CGSize = CGSize(width: 100, height: 100)) -> UIImage? {
        guard let fullImage = uiImage else { return nil }
        
        let renderer = UIGraphicsImageRenderer(size: size)
        return renderer.image { _ in
            fullImage.draw(in: CGRect(origin: .zero, size: size))
        }
    }

    /// Cached formatted date
    var formattedDate: String {
        if let cached = _cachedFormattedDate {
            return cached
        }
        
        let date = purchaseDate ?? timestamp
        let formatted = DateFormatterPool.shared.format(date)
        _cachedFormattedDate = formatted
        return formatted
    }

    /// A short title for lists
    var displayTitle: String {
        // This is thread-safe as it only accesses stored properties
        if let store = storeName, !store.isEmpty {
            return store
        } else if let barcode = barcodeValue {
            return "Barcode: \(barcode)"
        } else {
            return "Receipt"
        }
    }
    
    /// Clear cached values when underlying data changes
    func invalidateCache() {
        _cachedUIImage = nil
        _cachedFormattedDate = nil
        _cachedFormattedTotal = nil
        _cachedItems = nil
        _cachedDetailedItems = nil
    }
}

// MARK: - Stored Line Item Model

/// Codable line item for JSON storage in SwiftData
struct StoredLineItem: Codable, Identifiable, Equatable {
    var id: UUID
    let name: String
    let quantity: Int
    let unitPrice: Double?
    let totalPrice: Double?
    
    init(name: String, quantity: Int = 1, unitPrice: Double? = nil, totalPrice: Double? = nil) {
        self.id = UUID()
        self.name = name
        self.quantity = quantity
        self.unitPrice = unitPrice
        self.totalPrice = totalPrice
    }
    
    /// Convert from DetailedLineItem (from parser)
    init(from detailed: DetailedLineItem) {
        self.id = UUID()
        self.name = detailed.name
        self.quantity = detailed.quantity
        self.unitPrice = detailed.unitPrice
        self.totalPrice = detailed.totalPrice
    }
    
    var displayString: String {
        var result = name
        if quantity > 1 {
            result += " (x\(quantity))"
        }
        if let price = totalPrice ?? unitPrice {
            result += " $\(String(format: "%.2f", price))"
        }
        return result
    }
    
    /// Effective price (total or calculated from unit * qty)
    var effectivePrice: Double? {
        if let total = totalPrice {
            return total
        } else if let unit = unitPrice {
            return unit * Double(quantity)
        }
        return nil
    }
}

// MARK: - DateFormatter Pool

/// Reuse DateFormatter instances (expensive to create)
class DateFormatterPool {
    static let shared = DateFormatterPool()
    
    private let formatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter
    }()
    
    private init() {}
    
    func format(_ date: Date) -> String {
        formatter.string(from: date)
    }
}
