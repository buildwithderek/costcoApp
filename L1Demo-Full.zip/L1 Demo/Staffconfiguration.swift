//
//  StaffConfiguration.swift
//  L1 Demo
//
//  Staff names configuration for audit dropdowns
//  Edit this file to add/remove staff members
//

import Foundation

/// Represents a staff member option for picker
struct StaffOption: Identifiable, Hashable {
    let id = UUID()
    let name: String
    
    /// Display text (shows dash for empty)
    var displayName: String {
        name.isEmpty ? "—" : name
    }
}

/// Staff configuration for your Costco location
/// Edit these arrays to match your team
enum StaffConfiguration {
    
    // MARK: - Security Team
    /// Door checkers / Security staff
    static let securityNames: [String] = [
        "",  // Empty option for no selection
        "JOSE L",
        "LIONEL",
        "NICAY",
        "GRISE",
        "HENR",
        "LESLI",
        "JESSI",
        "TIM",
        "ERICK",
        "LUPITA",
        "EDITH"
    ]
    
    // MARK: - Cashiers
    /// Cashier names (not cashier numbers - those come from receipt)
    static let cashierNames: [String] = [
        "",  // Empty option
        "SCO",  // Self-checkout
        "JERMAINE",
        "DEREK",
        "ANTHONY",
        "VICTOR",
        "MARTIN",
        "KELLY",
        "ANASTACIO"
    ]
    
    // MARK: - Assistants
    /// Front-end assistants
    static let assistantNames: [String] = [
        "",  // Empty option
        "SCO-A",  // Self-checkout assistant (different from cashier SCO)
        "Diana",
        "DANI",
        "VINC",
        "NO",
        "JAZ",
        "XIM",
        "VICT"
    ]
    
    // MARK: - Supervisors
    /// Supervisors who sign off on audits
    static let supervisorNames: [String] = [
        "",  // Empty option
        "DGP",
        "ES",
        "CR",
        "GG",
        "DEE",
        "KR",
        "VH",
        "ER"
    ]
    
    // MARK: - Week Options
    /// Week options for period tracking
    static let weekOptions: [String] = [
        "Week 1",
        "Week 2",
        "Week 3",
        "Week 4",
        "Week 5"
    ]
    
    // MARK: - Helper Methods
    
    /// Get current week number
    static var currentWeek: String {
        let weekNum = Calendar.current.component(.weekOfMonth, from: Date())
        return "Week \(weekNum)"
    }
    
    /// Get current week of year
    static var currentWeekOfYear: Int {
        Calendar.current.component(.weekOfYear, from: Date())
    }
}
