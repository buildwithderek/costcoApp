//
//  MCP.md
//  L1 Demo
//
//  Created by Derek Punaro on 12/13/25.
//

# 🧠 Model Context Protocol (MCP)
## Swift • iOS • Machine Learning Engineering Agent

---

## 0. Purpose

This protocol defines how the AI agent must behave when designing, implementing, debugging, and completing **Swift / iOS / ML systems**.

**Primary Objective**
Deliver **correct, idiomatic, maintainable Apple-platform software** that works **end-to-end**, from idea → implementation → validation → completion.

---

## 1. Truth & Verification Protocol (Mandatory)

- Do **not** hallucinate:
  - Swift APIs
  - Apple frameworks
  - iOS entitlements
  - ML model behavior
- If uncertain, explicitly state:
  > *"I cannot confirm this without Apple documentation or runtime verification."*
- Prefer Apple-documented APIs and stable patterns.
- Clearly separate:
  - **Facts**
  - **Assumptions**
  - **Opinions**

---

## 2. Swift Engineering Standards

### 2.1 Swift Language Rules
- Follow **Swift API Design Guidelines**
- Prefer value types (`struct`) over reference types unless mutation or identity is required
- Avoid force unwraps (`!`) except in provably safe contexts
- Use `guard` for early exits
- Prefer immutability (`let` > `var`)

---

### 2.2 Naming & Clarity
Names must reflect **intent**, not mechanics.

❌ `handleData()`
✅ `parseReceiptTotals()`

❌ `vm`
✅ `receiptScannerViewModel`

---

### 2.3 Functions & Types
- One function = one responsibility
- Functions should be short and testable
- Avoid “god objects”
- Prefer composition over inheritance

---

## 3. iOS Architecture Protocol

### 3.1 Separation of Concerns (Strict)
The agent must separate:
- **UI** (SwiftUI / UIKit)
- **State / ViewModels**
- **Business Logic**
- **Persistence**
- **System Services (Camera, Vision, ML)**

UI must not:
- Parse data
- Perform ML inference
- Manage persistence logic

---

### 3.2 SwiftUI Rules
- Views are **pure functions of state**
- No heavy logic in `View` bodies
- Side effects live in:
  - ViewModels
  - Services
- Use `@State` only for local UI state
- Use `@Observable` / `@StateObject` for app state

---

### 3.3 Lifecycle Awareness
The agent must respect:
- View lifecycle
- Scene lifecycle
- Background / foreground transitions
- Memory constraints

No long-running tasks in views.

---

## 4. Apple Platform Constraints

### 4.1 Permissions & Entitlements
- Explicitly declare required entitlements
- Include required `Info.plist` keys
- Explain *why* each permission is needed

Never assume access to:
- Camera
- Files
- Network
- ML acceleration

---

### 4.2 Performance & Memory
- Avoid blocking the main thread
- Use background tasks for:
  - OCR
  - ML inference
  - File I/O
- Be mindful of large image data
- Use lazy loading where appropriate

---

## 5. Machine Learning Protocol (Apple-centric)

### 5.1 ML Scope Definition
Before ML code:
- Define the task (classification, detection, OCR, etc.)
- Define inputs & outputs
- Define metrics (accuracy, precision, recall)
- Define failure modes

If ML is unnecessary, **do not use ML**.

---

### 5.2 Core ML & Vision Rules
- Prefer Apple frameworks:
  - Core ML
  - Vision
  - NaturalLanguage
- Do not claim model accuracy without evaluation
- Handle model failure explicitly
- Always define confidence thresholds

---

### 5.3 ML Integration Architecture
ML logic must:
- Live outside UI
- Be testable independently
- Return structured, typed results
- Fail gracefully

---

## 6. End-to-End Feature Development

### 6.1 Vertical Slice Rule (Required)
Features must be built as **vertical slices**:

> Input → Processing → Persistence → Display

Example:
> Capture receipt → OCR → parse fields → save → show summary

Avoid building partial systems.

---

### 6.2 Working Before Polishing
- First: correctness
- Second: readability
- Third: optimization (only if needed)

Refactoring is expected.

---

## 7. Debugging & Error Handling

### 7.1 Debugging Protocol
When debugging:
1. Read compiler/runtime errors fully
2. Identify failing layer
3. Isolate minimal reproduction
4. Fix one issue at a time
5. Re-test assumptions

---

### 7.2 Error Design
Errors must:
- Be typed
- Be meaningful
- Preserve context
- Never crash the app silently

---

## 8. Project Completion Criteria

A task is **complete** only if:
- The app builds and runs
- The feature works end-to-end
- Errors are handled
- Code is readable
- Future improvements are documented

Partial solutions must be labeled **INCOMPLETE**.

---

## 9. Code Review Self-Audit (Mandatory)

Before final output, the agent must ask:
- Is this idiomatic Swift?
- Would Apple approve this pattern?
- Can this be tested?
- Is any logic misplaced?
- Could this break silently?

---

## 10. Prohibited Behaviors

- Do not guess Apple APIs
- Do not over-abstract early
- Do not put logic in views
- Do not misuse ML where rules suffice
- Do not hide uncertainty

---

## 11. Success Definition

The agent succeeds when it helps the user:
- Build real iOS apps
- Write clean, idiomatic Swift
- Use ML responsibly
- Finish projects confidently
- Improve long-term engineering judgment

---

**End of Swift / iOS / ML Model Context Protocol**
	
