//
//  AuditExportManager.swift
//  L1 Demo
//
//  Created by Claude (Code Review Fix)
//  Export manager for raw receipt data (non-editable exports from receipts list)
//

import Foundation

// MARK: - Export Errors

enum AuditExportError: LocalizedError {
    case noData
    case fileCreationFailed(path: String, underlyingError: Error)
    case verificationFailed(path: String)
    
    var errorDescription: String? {
        switch self {
        case .noData:
            return "No receipt data to export"
        case .fileCreationFailed(let path, let error):
            return "Failed to create file at \(path): \(error.localizedDescription)"
        case .verificationFailed(let path):
            return "File verification failed at \(path)"
        }
    }
}

// MARK: - Audit Export Manager

enum AuditExportManager {
    
    // MARK: - Configuration
    
    private static let headers = [
        "Date",
        "Store",
        "Total",
        "Register",
        "Transaction",
        "Cashier #",
        "Member ID",
        "Item Count",
        "Items",
        "Barcode"
    ]
    
    private static let dateFormatter: DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = "MM/dd/yyyy HH:mm"
        return f
    }()
    
    private static let filenameFormatter: DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = "MM-dd-yyyy_HHmmss"
        return f
    }()
    
    // MARK: - Debug Logging
    
    private static func debugLog(_ message: String, file: String = #file, line: Int = #line) {
        let fileName = (file as NSString).lastPathComponent
        print("📤 [AuditExport] [\(fileName):\(line)] \(message)")
    }
    
    // MARK: - Export Methods
    
    /// Export all receipts to CSV
    static func exportToCSV(receipts: [ReceiptItem]) throws -> URL {
        debugLog("🚀 Starting export for \(receipts.count) receipts")
        
        guard !receipts.isEmpty else {
            debugLog("❌ No receipts to export")
            throw AuditExportError.noData
        }
        
        // Build CSV content
        var lines = [headers.joined(separator: ",")]
        
        for (index, receipt) in receipts.enumerated() {
            debugLog("  Processing receipt \(index + 1)/\(receipts.count)")
            let row = createCSVRow(from: receipt)
            lines.append(row)
        }
        
        let csvText = lines.joined(separator: "\n") + "\n"
        debugLog("📊 Generated \(lines.count - 1) data rows, \(csvText.count) characters total")
        
        // Create unique filename with timestamp
        let dateStr = filenameFormatter.string(from: Date())
        let uniqueID = UUID().uuidString.prefix(6)
        let fileName = "receipts_export_\(dateStr)_\(uniqueID).csv"
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(fileName)
        
        debugLog("📁 Target file: \(fileName)")
        debugLog("📍 Full path: \(url.path)")
        
        // Check temp directory
        let tempDir = FileManager.default.temporaryDirectory
        let tempDirExists = FileManager.default.fileExists(atPath: tempDir.path)
        let tempDirWritable = FileManager.default.isWritableFile(atPath: tempDir.path)
        debugLog("📂 Temp dir exists: \(tempDirExists), writable: \(tempDirWritable)")
        
        do {
            // Write file
            try csvText.write(to: url, atomically: true, encoding: .utf8)
            debugLog("✅ Write completed")
            
            // Verify file was created
            let fileExists = FileManager.default.fileExists(atPath: url.path)
            let fileReadable = FileManager.default.isReadableFile(atPath: url.path)
            
            debugLog("🔍 Verification: exists=\(fileExists), readable=\(fileReadable)")
            
            if let attrs = try? FileManager.default.attributesOfItem(atPath: url.path) {
                let size = attrs[.size] as? Int64 ?? 0
                let created = attrs[.creationDate] as? Date
                debugLog("📏 File size: \(size) bytes")
                if let created = created {
                    debugLog("🕐 Created: \(created)")
                }
                
                if size == 0 {
                    debugLog("⚠️ WARNING: File is empty!")
                }
            }
            
            guard fileExists else {
                debugLog("❌ File does not exist after write!")
                throw AuditExportError.verificationFailed(path: url.path)
            }
            
            debugLog("✅ Export successful: \(url.lastPathComponent)")
            return url
            
        } catch let error as AuditExportError {
            throw error
        } catch {
            debugLog("❌ Write error: \(error.localizedDescription)")
            throw AuditExportError.fileCreationFailed(path: url.path, underlyingError: error)
        }
    }
    
    /// Export single receipt to CSV
    static func exportReceiptToCSV(_ receipt: ReceiptItem) throws -> URL {
        debugLog("📄 Exporting single receipt: \(receipt.displayTitle)")
        return try exportToCSV(receipts: [receipt])
    }
    
    // MARK: - CSV Row Generation
    
    private static func createCSVRow(from receipt: ReceiptItem) -> String {
        // Date
        let date = dateFormatter.string(from: receipt.purchaseDate ?? receipt.timestamp)
        
        // Basic fields
        let store = esc(receipt.storeName ?? "Unknown")
        let total = receipt.totalAmount.map { String(format: "%.2f", $0) } ?? ""
        
        // Costco fields
        let register = esc(receipt.registerNumber ?? "")
        let transaction = esc(receipt.transactionNumber ?? "")
        let cashier = esc(receipt.cashierNumber ?? "")
        let member = esc(receipt.memberID ?? "")
        let itemCount = receipt.expectedItemCount.map { String($0) } ?? ""
        
        // Items - combine all items into one cell
        let itemsList: String
        if !receipt.detailedItems.isEmpty {
            // Use detailed items with prices
            itemsList = receipt.detailedItems.map { item in
                var display = item.name
                if item.quantity > 1 {
                    display += " (x\(item.quantity))"
                }
                if let price = item.totalPrice ?? item.unitPrice {
                    display += " $\(String(format: "%.2f", price))"
                }
                return display
            }.joined(separator: "; ")
        } else if let items = receipt.items, !items.isEmpty {
            // Use simple items array
            itemsList = items.joined(separator: "; ")
        } else {
            itemsList = ""
        }
        
        let items = esc(itemsList)
        let barcode = esc(receipt.barcodeValue ?? "")
        
        // Build row
        return [
            date,
            store,
            total.isEmpty ? "" : "$\(total)",
            register,
            transaction,
            cashier,
            member,
            itemCount,
            items,
            barcode
        ].joined(separator: ",")
    }
    
    // MARK: - CSV Escaping
    
    /// Escape CSV field (handles commas, quotes, newlines)
    private static func esc(_ text: String) -> String {
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        
        // If no special characters, return as-is
        guard t.contains(",") || t.contains("\"") || t.contains("\n") else {
            return t
        }
        
        // Escape quotes and wrap in quotes
        return "\"\(t.replacingOccurrences(of: "\"", with: "\"\""))\""
    }
    
    // MARK: - Utility Methods
    
    /// List CSV files in temp directory (for debugging)
    static func listTempCSVFiles() -> [String] {
        let tempDir = FileManager.default.temporaryDirectory
        guard let contents = try? FileManager.default.contentsOfDirectory(atPath: tempDir.path) else {
            return []
        }
        return contents.filter { $0.hasSuffix(".csv") }.sorted()
    }
    
    /// Print debug info about temp directory
    static func debugTempDirectory() {
        debugLog("📂 Temp directory contents:")
        for file in listTempCSVFiles() {
            let path = FileManager.default.temporaryDirectory.appendingPathComponent(file).path
            if let attrs = try? FileManager.default.attributesOfItem(atPath: path),
               let size = attrs[.size] as? Int64 {
                debugLog("  - \(file) (\(size) bytes)")
            } else {
                debugLog("  - \(file) (size unknown)")
            }
        }
    }
}
