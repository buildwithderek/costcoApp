//
//  QuickAuditView.swift
//  L1 Demo
//
//  REDESIGNED: Streamlined audit view with collapsible issue cards,
//  progressive disclosure, and sticky action bar
//
//  UX Improvements:
//  - Collapsible overcharge/undercharge cards
//  - Receipt card with key info at glance
//  - Sticky save/complete buttons
//  - Progressive disclosure for details
//  - Costco brand theming
//

import SwiftUI

// MARK: - Costco Brand Colors

enum CostcoTheme {
    static let red = Color(red: 0.89, green: 0.12, blue: 0.17)      // #E31E2B
    static let blue = Color(red: 0.0, green: 0.32, blue: 0.65)       // #0052A5
    static let darkBlue = Color(red: 0.0, green: 0.24, blue: 0.49)   // #003D7D
}

// MARK: - Quick Audit View

struct QuickAuditView: View {
    @Binding var auditData: ReceiptAuditData
    let receipt: ReceiptItem?
    let onComplete: () -> Void
    let onSave: () -> Void
    
    @State private var showingDetails = false
    @State private var showingImage = false
    @State private var showingAllItems = false
    
    var body: some View {
        ZStack(alignment: .bottom) {
            ScrollView {
                VStack(spacing: 20) {
                    // Receipt Preview Card
                    receiptCard
                    
                    // Primary Input: Issues Found
                    issuesSection
                    
                    // Quick Staff Selection
                    staffSection
                    
                    // Audit Checks
                    checksSection
                    
                    // Expandable Details
                    if showingDetails {
                        detailsSection
                            .transition(.opacity.combined(with: .move(edge: .top)))
                    }
                    
                    // Toggle for details
                    Button {
                        withAnimation(.spring(response: 0.3, dampingFraction: 0.8)) {
                            showingDetails.toggle()
                        }
                    } label: {
                        HStack(spacing: 6) {
                            Text(showingDetails ? "Hide Details" : "Show More Details")
                            Image(systemName: showingDetails ? "chevron.up" : "chevron.down")
                        }
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .padding(.vertical, 8)
                    }
                    
                    // Bottom spacing for action bar
                    Spacer(minLength: 100)
                }
                .padding()
            }
            
            // Sticky Action Bar
            actionBar
        }
        .background(Color(.systemGroupedBackground))
        .navigationTitle("Quick Audit")
        .sheet(isPresented: $showingImage) {
            if let image = receipt?.uiImage {
                ImagePreviewSheet(image: image)
            }
        }
        .sheet(isPresented: $showingAllItems) {
            AllItemsSheet(items: auditData.lineItems)
        }
    }
    
    // MARK: - Receipt Card
    
    private var receiptCard: some View {
        VStack(spacing: 0) {
            HStack(spacing: 16) {
                // Thumbnail - tap to view full
                Button {
                    showingImage = true
                } label: {
                    ZStack(alignment: .bottomTrailing) {
                        if let thumb = receipt?.thumbnail(size: CGSize(width: 160, height: 200)) {
                            Image(uiImage: thumb)
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .frame(width: 80, height: 100)
                                .cornerRadius(8)
                        } else {
                            RoundedRectangle(cornerRadius: 8)
                                .fill(Color.gray.opacity(0.15))
                                .frame(width: 80, height: 100)
                                .overlay(
                                    Image(systemName: "doc.text")
                                        .font(.title2)
                                        .foregroundColor(.gray)
                                )
                        }
                        
                        // Magnifier icon
                        Image(systemName: "magnifyingglass.circle.fill")
                            .font(.caption)
                            .foregroundColor(.white)
                            .background(Color.black.opacity(0.5))
                            .clipShape(Circle())
                            .offset(x: 4, y: 4)
                    }
                }
                .buttonStyle(.plain)
                
                // Receipt Info
                VStack(alignment: .leading, spacing: 8) {
                    // Transaction ID
                    HStack(spacing: 4) {
                        if !auditData.register.isEmpty {
                            Label("Reg \(auditData.register)", systemImage: "printer")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        
                        if !auditData.ring.isEmpty {
                            Text("•")
                                .foregroundColor(.secondary)
                            Text("#\(auditData.ring)")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                    
                    // Total
                    if let total = auditData.receiptTotal {
                        Text(String(format: "$%.2f", total))
                            .font(.title)
                            .fontWeight(.bold)
                            .foregroundColor(.primary)
                    }
                    
                    // Item Count with validation
                    HStack(spacing: 6) {
                        let count = auditData.lineItems.count
                        let expected = auditData.expectedItemCount ?? 0
                        let isMatch = expected == 0 || count == expected
                        
                        Image(systemName: isMatch ? "checkmark.circle.fill" : "exclamationmark.triangle.fill")
                            .foregroundColor(isMatch ? .green : .orange)
                            .font(.caption)
                        
                        Text("\(count) items")
                            .font(.subheadline)
                            .foregroundColor(.primary)
                        
                        if expected > 0 && !isMatch {
                            Text("(expected \(expected))")
                                .font(.caption)
                                .foregroundColor(.orange)
                        }
                    }
                    
                    // Time
                    HStack(spacing: 4) {
                        Image(systemName: "clock")
                            .font(.caption2)
                        Text(formattedTime)
                            .font(.caption)
                    }
                    .foregroundColor(.secondary)
                }
                
                Spacer()
            }
            .padding(16)
        }
        .background(Color(.systemBackground))
        .cornerRadius(16)
        .shadow(color: .black.opacity(0.05), radius: 5, y: 2)
    }
    
    private var formattedTime: String {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        return formatter.string(from: auditData.date)
    }
    
    // MARK: - Issues Section
    
    private var issuesSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Issues Found")
                .font(.headline)
                .padding(.horizontal, 4)
            
            // Overcharge Card - Costco Red
            IssueInputCard(
                title: "Overcharge",
                subtitle: "Item charged but not in basket",
                iconName: "arrow.up.circle.fill",
                iconColor: CostcoTheme.red,
                itemNumber: $auditData.itemOvercharge,
                itemName: $auditData.itemOverchargeName,
                itemCost: $auditData.itemOverchargeCost,
                onLookup: {
                    auditData.lookupOverchargeDetails()
                }
            )
            
            // Undercharge Card
            IssueInputCard(
                title: "Undercharge",
                subtitle: "Item in basket but not charged",
                iconName: "arrow.down.circle.fill",
                iconColor: .orange,
                itemNumber: $auditData.itemUndercharge,
                itemName: $auditData.itemUnderchargeName,
                itemCost: $auditData.itemUnderchargeCost,
                onLookup: {
                    auditData.lookupUnderchargeDetails()
                }
            )
        }
    }
    
    // MARK: - Staff Section
    
    private var staffSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Staff")
                .font(.headline)
                .padding(.horizontal, 4)
            
            VStack(spacing: 12) {
                HStack(spacing: 12) {
                    CompactPicker(
                        label: "Security",
                        selection: $auditData.security,
                        options: StaffConfiguration.securityNames
                    )
                    
                    CompactPicker(
                        label: "Supervisor",
                        selection: $auditData.supervisor,
                        options: StaffConfiguration.supervisorNames
                    )
                }
            }
            .padding(16)
            .background(Color(.systemBackground))
            .cornerRadius(12)
        }
    }
    
    // MARK: - Checks Section
    
    private var checksSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Audit Checks")
                .font(.headline)
                .padding(.horizontal, 4)
            
            LazyVGrid(columns: [
                GridItem(.flexible()),
                GridItem(.flexible())
            ], spacing: 10) {
                CheckToggle(label: "B.O.B", isOn: $auditData.bob)
                CheckToggle(label: "3/Total", isOn: $auditData.threeTotal)
                CheckToggle(label: "Prescan", isOn: $auditData.prescan)
                CheckToggle(label: "Basket Match", isOn: $auditData.prescanMatchesBasket)
            }
            .padding(16)
            .background(Color(.systemBackground))
            .cornerRadius(12)
        }
    }
    
    // MARK: - Details Section
    
    private var detailsSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            // Transaction Details
            VStack(alignment: .leading, spacing: 12) {
                Text("Transaction Details")
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .foregroundColor(.secondary)
                
                DetailRow(label: "Register", value: auditData.register)
                DetailRow(label: "Transaction #", value: auditData.ring)
                DetailRow(label: "Cashier #", value: auditData.cashierNumber)
                DetailRow(label: "Member ID", value: auditData.memberID)
                DetailRow(label: "Week", value: auditData.week)
            }
            
            Divider()
            
            // Line Items Preview
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text("Line Items (\(auditData.lineItems.count))")
                        .font(.subheadline)
                        .fontWeight(.medium)
                        .foregroundColor(.secondary)
                    
                    Spacer()
                    
                    if auditData.lineItems.count > 5 {
                        Button("View All") {
                            showingAllItems = true
                        }
                        .font(.caption)
                        .foregroundColor(CostcoTheme.blue)
                    }
                }
                
                if auditData.lineItems.isEmpty {
                    Text("No items detected")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .italic()
                } else {
                    ForEach(auditData.lineItems.prefix(5)) { item in
                        HStack {
                            Text(item.name)
                                .font(.caption)
                                .lineLimit(1)
                            Spacer()
                            if !item.cost.isEmpty {
                                Text("$\(item.cost)")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                        }
                    }
                    
                    if auditData.lineItems.count > 5 {
                        Text("+\(auditData.lineItems.count - 5) more items...")
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .italic()
                    }
                }
            }
            
            Divider()
            
            // Additional Staff
            VStack(alignment: .leading, spacing: 12) {
                Text("Additional Staff")
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .foregroundColor(.secondary)
                
                HStack(spacing: 12) {
                    CompactPicker(
                        label: "Cashier",
                        selection: $auditData.cashier,
                        options: StaffConfiguration.cashierNames
                    )
                    
                    CompactPicker(
                        label: "Assistant",
                        selection: $auditData.assistant,
                        options: StaffConfiguration.assistantNames
                    )
                }
            }
        }
        .padding(16)
        .background(Color(.systemBackground))
        .cornerRadius(12)
    }
    
    // MARK: - Action Bar
    
    private var actionBar: some View {
        VStack(spacing: 0) {
            Divider()
            
            HStack(spacing: 12) {
                // Save Button
                Button {
                    onSave()
                } label: {
                    Text("Save")
                        .fontWeight(.medium)
                        .foregroundColor(CostcoTheme.blue)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(CostcoTheme.blue.opacity(0.12))
                        .cornerRadius(12)
                }
                
                // Complete Button
                Button {
                    onComplete()
                } label: {
                    HStack(spacing: 8) {
                        Image(systemName: "checkmark.circle.fill")
                        Text("Complete")
                    }
                    .fontWeight(.semibold)
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(CostcoTheme.blue)
                    .cornerRadius(12)
                }
            }
            .padding(16)
            .background(.ultraThinMaterial)
        }
    }
}

// MARK: - Issue Input Card

struct IssueInputCard: View {
    let title: String
    let subtitle: String
    let iconName: String
    let iconColor: Color
    @Binding var itemNumber: String
    @Binding var itemName: String
    @Binding var itemCost: String
    var onLookup: (() -> Void)? = nil
    
    @State private var isExpanded = false
    
    private var hasValue: Bool {
        !itemNumber.isEmpty || !itemName.isEmpty || !itemCost.isEmpty
    }
    
    var body: some View {
        VStack(spacing: 0) {
            // Header - Always visible
            Button {
                withAnimation(.spring(response: 0.3, dampingFraction: 0.8)) {
                    isExpanded.toggle()
                }
            } label: {
                HStack(spacing: 12) {
                    // Icon
                    Image(systemName: iconName)
                        .font(.title2)
                        .foregroundColor(iconColor)
                    
                    // Title & Status
                    VStack(alignment: .leading, spacing: 2) {
                        Text(title)
                            .font(.subheadline)
                            .fontWeight(.semibold)
                            .foregroundColor(.primary)
                        
                        if hasValue {
                            Text(itemNumber.isEmpty ? itemName : "Item #\(itemNumber)")
                                .font(.caption)
                                .foregroundColor(iconColor)
                        } else {
                            Text(subtitle)
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                    
                    Spacer()
                    
                    // Status indicator
                    if hasValue {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundColor(iconColor)
                    }
                    
                    // Chevron
                    Image(systemName: isExpanded ? "chevron.up" : "chevron.down")
                        .font(.caption)
                        .foregroundColor(.gray)
                }
                .padding(16)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            
            // Expanded Fields
            if isExpanded {
                VStack(spacing: 12) {
                    Divider()
                        .padding(.horizontal, 16)
                    
                    VStack(spacing: 10) {
                        // Item Number
                        HStack {
                            Text("Item #")
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                                .frame(width: 60, alignment: .leading)
                            
                            TextField("Enter item number", text: $itemNumber)
                                .keyboardType(.numberPad)
                                .textFieldStyle(.roundedBorder)
                                .onChange(of: itemNumber) { _, _ in
                                    onLookup?()
                                }
                        }
                        
                        // Item Name
                        HStack {
                            Text("Name")
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                                .frame(width: 60, alignment: .leading)
                            
                            TextField("Item name", text: $itemName)
                                .textFieldStyle(.roundedBorder)
                        }
                        
                        // Cost
                        HStack {
                            Text("Cost")
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                                .frame(width: 60, alignment: .leading)
                            
                            HStack(spacing: 4) {
                                Text("$")
                                    .foregroundColor(.secondary)
                                TextField("0.00", text: $itemCost)
                                    .keyboardType(.decimalPad)
                                    .textFieldStyle(.roundedBorder)
                            }
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.bottom, 16)
                }
                .transition(.opacity.combined(with: .move(edge: .top)))
            }
        }
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .shadow(color: .black.opacity(0.03), radius: 3, y: 1)
        .onAppear {
            // Auto-expand if has value
            if hasValue {
                isExpanded = true
            }
        }
    }
}

// MARK: - Compact Picker

struct CompactPicker: View {
    let label: String
    @Binding var selection: String
    let options: [String]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(label)
                .font(.caption)
                .foregroundColor(.secondary)
            
            Menu {
                ForEach(options, id: \.self) { option in
                    Button {
                        selection = option
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    } label: {
                        if option == selection {
                            Label(option.isEmpty ? "—" : option, systemImage: "checkmark")
                        } else {
                            Text(option.isEmpty ? "—" : option)
                        }
                    }
                }
            } label: {
                HStack {
                    Text(selection.isEmpty ? "Select" : selection)
                        .font(.subheadline)
                        .foregroundColor(selection.isEmpty ? .secondary : .primary)
                        .lineLimit(1)
                    
                    Spacer()
                    
                    Image(systemName: "chevron.up.chevron.down")
                        .font(.caption2)
                        .foregroundColor(.gray)
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 10)
                .background(Color(.tertiarySystemBackground))
                .cornerRadius(8)
            }
        }
    }
}

// MARK: - Check Toggle

struct CheckToggle: View {
    let label: String
    @Binding var isOn: Bool
    
    var body: some View {
        Button {
            isOn.toggle()
            UIImpactFeedbackGenerator(style: .light).impactOccurred()
        } label: {
            HStack(spacing: 8) {
                Image(systemName: isOn ? "checkmark.square.fill" : "square")
                    .font(.body)
                    .foregroundColor(isOn ? CostcoTheme.blue : .gray)
                
                Text(label)
                    .font(.subheadline)
                    .foregroundColor(.primary)
                
                Spacer()
            }
            .padding(12)
            .background(isOn ? CostcoTheme.blue.opacity(0.1) : Color(.tertiarySystemBackground))
            .cornerRadius(8)
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Detail Row

struct DetailRow: View {
    let label: String
    let value: String
    
    var body: some View {
        HStack {
            Text(label)
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            Spacer()
            
            Text(value.isEmpty ? "—" : value)
                .font(.subheadline)
                .foregroundColor(value.isEmpty ? .secondary : .primary)
        }
    }
}

// MARK: - Image Preview Sheet

struct ImagePreviewSheet: View {
    let image: UIImage
    @Environment(\.dismiss) private var dismiss
    
    @State private var scale: CGFloat = 1.0
    @State private var lastScale: CGFloat = 1.0
    @State private var offset: CGSize = .zero
    @State private var lastOffset: CGSize = .zero
    
    private let minScale: CGFloat = 1.0
    private let maxScale: CGFloat = 5.0
    
    var body: some View {
        NavigationStack {
            GeometryReader { geometry in
                ZStack {
                    Color.black.ignoresSafeArea()
                    
                    Image(uiImage: image)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .scaleEffect(scale)
                        .offset(offset)
                        .gesture(
                            MagnificationGesture()
                                .onChanged { value in
                                    let delta = value / lastScale
                                    lastScale = value
                                    scale = min(max(scale * delta, minScale), maxScale)
                                }
                                .onEnded { _ in
                                    lastScale = 1.0
                                    // Reset offset if zoomed out
                                    if scale <= 1.0 {
                                        withAnimation(.spring()) {
                                            offset = .zero
                                        }
                                    }
                                }
                        )
                        .simultaneousGesture(
                            DragGesture()
                                .onChanged { value in
                                    if scale > 1.0 {
                                        offset = CGSize(
                                            width: lastOffset.width + value.translation.width,
                                            height: lastOffset.height + value.translation.height
                                        )
                                    }
                                }
                                .onEnded { _ in
                                    lastOffset = offset
                                }
                        )
                        .simultaneousGesture(
                            TapGesture(count: 2)
                                .onEnded {
                                    withAnimation(.spring()) {
                                        if scale > 1.0 {
                                            // Zoom out to fit
                                            scale = 1.0
                                            offset = .zero
                                            lastOffset = .zero
                                        } else {
                                            // Zoom in to 2.5x
                                            scale = 2.5
                                        }
                                    }
                                }
                        )
                        .frame(width: geometry.size.width, height: geometry.size.height)
                }
            }
            .navigationTitle("Receipt Image")
            .navigationBarTitleDisplayMode(.inline)
            .toolbarBackground(.visible, for: .navigationBar)
            .toolbarBackground(Color.black.opacity(0.8), for: .navigationBar)
            .toolbarColorScheme(.dark, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    // Zoom indicator
                    Text("\(Int(scale * 100))%")
                        .font(.caption)
                        .foregroundColor(.white.opacity(0.7))
                        .monospacedDigit()
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        dismiss()
                    }
                    .foregroundColor(.white)
                }
            }
        }
    }
}

// MARK: - All Items Sheet

struct AllItemsSheet: View {
    let items: [EditableLineItem]
    @Environment(\.dismiss) private var dismiss
    
    private var totalCost: Double {
        items.reduce(0) { sum, item in
            let qty = Double(item.quantity) ?? 1
            let cost = Double(item.cost) ?? 0
            return sum + (qty * cost)
        }
    }
    
    var body: some View {
        NavigationStack {
            List {
                Section {
                    ForEach(items) { item in
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(item.name)
                                    .font(.subheadline)
                                
                                if item.quantity != "1" {
                                    Text("Qty: \(item.quantity)")
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                }
                            }
                            
                            Spacer()
                            
                            if !item.cost.isEmpty {
                                Text("$\(item.cost)")
                                    .font(.subheadline)
                                    .foregroundColor(.green)
                            }
                        }
                    }
                } header: {
                    Text("\(items.count) Items")
                } footer: {
                    if totalCost > 0 {
                        HStack {
                            Spacer()
                            Text("Total: $\(String(format: "%.2f", totalCost))")
                                .font(.headline)
                        }
                    }
                }
            }
            .navigationTitle("Line Items")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
        }
    }
}

// MARK: - Preview

#Preview {
    NavigationStack {
        QuickAuditView(
            auditData: .constant(ReceiptAuditData.preview),
            receipt: nil,
            onComplete: {},
            onSave: {}
        )
    }
}

// MARK: - Preview Helper

extension ReceiptAuditData {
    static var preview: ReceiptAuditData {
        var data = ReceiptAuditData.__preview_init()
        return data
    }
    
    // For preview only
    static func __preview_init() -> ReceiptAuditData {
        ReceiptAuditData(
            id: UUID(),
            receiptID: UUID(),
            receiptTitle: "Costco",
            receiptFormattedDate: "Dec 16, 2025",
            receiptTotal: 117.44,
            hasImage: true,
            rawText: nil,
            expectedItemCount: 12,
            date: Date(),
            register: "424",
            ring: "128",
            cashierNumber: "357",
            bob: false,
            threeTotal: false,
            prescan: false,
            prescanMatchesBasket: false,
            itemOvercharge: "",
            itemOverchargeName: "",
            itemOverchargeCost: "",
            itemUndercharge: "",
            itemUnderchargeName: "",
            itemUnderchargeCost: "",
            storeName: "Costco",
            totalAmount: "117.44",
            security: "",
            cashier: "",
            assistant: "",
            supervisor: "",
            week: "Week 3",
            memberID: "111970946598",
            lineItems: [
                EditableLineItem(name: "TANGERINE JU", quantity: "1", cost: "9.39"),
                EditableLineItem(name: "KS ORG WH MK", quantity: "1", cost: "11.24"),
                EditableLineItem(name: "PET THROW", quantity: "1", cost: "19.99"),
                EditableLineItem(name: "TIDE W/DOWNY", quantity: "1", cost: "19.49"),
                EditableLineItem(name: "SUCK CORN 6", quantity: "1", cost: "4.29")
            ]
        )
    }
    
    // Memberwise init for preview
    init(
        id: UUID,
        receiptID: UUID,
        receiptTitle: String,
        receiptFormattedDate: String,
        receiptTotal: Double?,
        hasImage: Bool,
        rawText: String?,
        expectedItemCount: Int?,
        date: Date,
        register: String,
        ring: String,
        cashierNumber: String,
        bob: Bool,
        threeTotal: Bool,
        prescan: Bool,
        prescanMatchesBasket: Bool,
        itemOvercharge: String,
        itemOverchargeName: String,
        itemOverchargeCost: String,
        itemUndercharge: String,
        itemUnderchargeName: String,
        itemUnderchargeCost: String,
        storeName: String,
        totalAmount: String,
        security: String,
        cashier: String,
        assistant: String,
        supervisor: String,
        week: String,
        memberID: String,
        lineItems: [EditableLineItem]
    ) {
        self.id = id
        self.receiptID = receiptID
        self.receiptTitle = receiptTitle
        self.receiptFormattedDate = receiptFormattedDate
        self.receiptTotal = receiptTotal
        self.hasImage = hasImage
        self.rawText = rawText
        self.expectedItemCount = expectedItemCount
        self.date = date
        self.register = register
        self.ring = ring
        self.cashierNumber = cashierNumber
        self.bob = bob
        self.threeTotal = threeTotal
        self.prescan = prescan
        self.prescanMatchesBasket = prescanMatchesBasket
        self.itemOvercharge = itemOvercharge
        self.itemOverchargeName = itemOverchargeName
        self.itemOverchargeCost = itemOverchargeCost
        self.itemUndercharge = itemUndercharge
        self.itemUnderchargeName = itemUnderchargeName
        self.itemUnderchargeCost = itemUnderchargeCost
        self.storeName = storeName
        self.totalAmount = totalAmount
        self.security = security
        self.cashier = cashier
        self.assistant = assistant
        self.supervisor = supervisor
        self.week = week
        self.memberID = memberID
        self.lineItems = lineItems
    }
}
