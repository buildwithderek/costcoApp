//
//  L1_DemoApp.swift
//  APP POINT ENTRY
//
//  Created by Derek Punaro on 10/3/25.
//

import SwiftUI
import SwiftData

@main
struct L1_DemoApp: App {
    /// Shared SwiftData container for the whole app
    var sharedModelContainer: ModelContainer = {
        let schema = Schema([
            ReceiptItem.self,
        ])
        
        // Persist to disk (not in-memory)
        let modelConfiguration = ModelConfiguration(
            schema: schema,
            isStoredInMemoryOnly: false
        )

        do {
            return try ModelContainer(
                for: schema,
                configurations: [modelConfiguration]
            )
        } catch {
            fatalError("❌ Could not create ModelContainer: \(error)")
        }
    }()

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        .modelContainer(sharedModelContainer)
    }
}
