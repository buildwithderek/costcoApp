import SwiftUI

/// Shows one receipt in detail.
/// NOTE: Individual CSV export has been removed — use the daily export from the audit/export screen.
struct ReceiptDetailView: View {
    let receipt: ReceiptItem

    @State private var showRawText = false
    @State private var receiptItems: [String] = []
    @State private var detailedItems: [StoredLineItem] = []
    @State private var receiptImage: UIImage?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {

                // Image (or barcode fallback)
                if let image = receiptImage {
                    Image(uiImage: image)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(12)
                        .shadow(radius: 4)
                } else if let barcode = receipt.barcodeValue {
                    HStack {
                        Image(systemName: "barcode")
                        Text(barcode)
                    }
                    .font(.title3)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(12)
                }

                // Basic info
                VStack(alignment: .leading, spacing: 8) {
                    Text(receipt.displayTitle)
                        .font(.title2)
                        .fontWeight(.semibold)

                    Text(receipt.formattedDate)
                        .font(.subheadline)
                        .foregroundColor(.secondary)

                    if let total = receipt.totalAmount {
                        Text(String(format: "Total: $%.2f", total))
                            .font(.headline)
                            .foregroundColor(.green)
                    }

                    if let barcode = receipt.barcodeValue {
                        HStack(spacing: 6) {
                            Text("Barcode:")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            Text(barcode)
                                .font(.caption)
                                .fontWeight(.medium)
                        }
                    }
                }

                Divider()

                // Line items
                if !detailedItems.isEmpty {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Items (\(detailedItems.count))")
                            .font(.headline)

                        ForEach(detailedItems) { item in
                            Text("• \(item.displayString)")
                                .font(.subheadline)
                        }
                    }
                } else if !receiptItems.isEmpty {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Items (\(receiptItems.count))")
                            .font(.headline)

                        ForEach(receiptItems, id: \.self) { item in
                            Text("• \(item)")
                                .font(.subheadline)
                        }
                    }
                } else {
                    Text("No items found for this receipt.")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }

                // Raw text toggle
                if let rawText = receipt.rawText, !rawText.isEmpty {
                    Divider()

                    Button {
                        withAnimation { showRawText.toggle() }
                    } label: {
                        HStack {
                            Image(systemName: showRawText ? "chevron.down" : "chevron.right")
                            Text("Show raw receipt text")
                        }
                    }

                    if showRawText {
                        ScrollView {
                            Text(rawText)
                                .font(.footnote)
                                .padding(8)
                        }
                        .frame(minHeight: 120)
                        .background(Color.gray.opacity(0.1))
                        .cornerRadius(8)
                    }
                }

                Divider()

                // Helpful hint so you don't hunt for export here anymore
                Text("Export is done from the Daily Audit screen (exports all receipts for the day into one CSV).")
                    .font(.footnote)
                    .foregroundColor(.secondary)
                    .padding(.top, 4)
            }
            .padding()
        }
        .navigationTitle("Receipt Detail")
        .navigationBarTitleDisplayMode(.inline)
        .task { await loadReceiptData() }
    }

    // MARK: - Load Data

    private func loadReceiptData() async {
        let image = receipt.uiImage
        let items = receipt.items ?? []
        let detailed = receipt.detailedItems

        await MainActor.run {
            receiptImage = image
            receiptItems = items
            detailedItems = detailed
        }
    }
}
