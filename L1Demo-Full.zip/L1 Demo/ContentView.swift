//
//  ContentView.swift
//  L1 Demo
//
//  REDESIGNED: Home screen with progress tracking, visual hierarchy, and improved UX
//  Created by Derek Punaro on 10/3/25.
//  UX Redesign: December 2025
//

import SwiftUI
import SwiftData
import AVFoundation

// MARK: - Constants
private enum ReceiptConstants {
    static let maxImageDimension: CGFloat = 1920
    static let jpegCompression: CGFloat = 0.5
    static let toastDuration: TimeInterval = 2
    static let thumbnailSize = CGSize(width: 100, height: 100)
}

// MARK: - Processing Errors
enum ReceiptProcessingError: LocalizedError {
    case imageProcessingFailed
    case visionProcessingFailed(Error)
    case ocrProcessingFailed(Error)
    case saveFailed(Error)
    
    var errorDescription: String? {
        switch self {
        case .imageProcessingFailed:
            return "Failed to process image"
        case .visionProcessingFailed(let error):
            return "Vision processing failed: \(error.localizedDescription)"
        case .ocrProcessingFailed(let error):
            return "OCR processing failed: \(error.localizedDescription)"
        case .saveFailed(let error):
            return "Failed to save receipt: \(error.localizedDescription)"
        }
    }
}

// MARK: - Costco Brand Colors

enum CostcoColors {
    static let red = Color(red: 0.89, green: 0.12, blue: 0.17)      // #E31E2B
    static let blue = Color(red: 0.0, green: 0.32, blue: 0.65)       // #0052A5
    static let darkBlue = Color(red: 0.0, green: 0.24, blue: 0.49)   // #003D7D
    static let lightGray = Color(red: 0.95, green: 0.95, blue: 0.95) // #F2F2F2
}

// MARK: - Main Content View

struct ContentView: View {
    @Environment(\.modelContext) private var modelContext
    
    @Query(sort: \ReceiptItem.timestamp, order: .reverse)
    private var allReceipts: [ReceiptItem]
    
    @State private var showingCamera = false
    @State private var showingExport = false
    @State private var showSuccessMessage = false
    @State private var isProcessing = false
    @State private var errorMessage: String?
    @State private var showErrorAlert = false
    
    // Computed properties for today's data
    private var todaysReceipts: [ReceiptItem] {
        let calendar = Calendar.current
        return allReceipts.filter {
            calendar.isDateInToday($0.purchaseDate ?? $0.timestamp)
        }
    }
    private var completedCount: Int {
        todaysReceipts.filter { $0.auditCompleted }.count
    }
    
    private var hasIssues: Bool {
        todaysReceipts.contains {
            ($0.auditItemOvercharge != nil && !$0.auditItemOvercharge!.isEmpty) ||
            ($0.auditItemUndercharge != nil && !$0.auditItemUndercharge!.isEmpty)
        }
    }
    
    var body: some View {
        NavigationStack {
            ZStack {
                // Background
                Color(.systemGroupedBackground)
                    .ignoresSafeArea()
                
                ScrollView {
                    VStack(spacing: 20) {
                        // Costco Header
                        costcoHeader
                        
                        // Progress Card
                        progressCard
                        
                        // Primary Action - Scan Button
                        scanButton
                        
                        // Recent Audits (if any today)
                        if !todaysReceipts.isEmpty {
                            recentAuditsSection
                        }
                        
                        // Export Button
                        if !todaysReceipts.isEmpty {
                            exportButton
                        }
                        
                        // Quick Stats
                        if !allReceipts.isEmpty {
                            statsSection
                        }
                    }
                    .padding()
                }
                
                // Success Toast
                if showSuccessMessage {
                    VStack {
                        Spacer()
                        SuccessToast()
                    }
                    .transition(.move(edge: .bottom).combined(with: .opacity))
                    .animation(.spring(), value: showSuccessMessage)
                }
                
                // Processing Overlay
                if isProcessing {
                    ProcessingOverlay()
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Text("Door Audit")
                        .font(.headline)
                        .foregroundColor(CostcoColors.blue)
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    NavigationLink(destination: ReceiptsListView()) {
                        Image(systemName: "list.bullet.rectangle")
                            .foregroundColor(CostcoColors.blue)
                    }
                    .accessibilityLabel("View all receipts")
                }
            }
            .sheet(isPresented: $showingCamera) {
                ReceiptCameraView(
                    onPhotoCaptured: handlePhotoCaptured,
                    onCancel: { showingCamera = false }
                )
                .ignoresSafeArea()
            }
            .sheet(isPresented: $showingExport) {
                DailyAuditExportView(receipts: Array(todaysReceipts))
            }
            .alert("Error", isPresented: $showErrorAlert) {
                Button("OK") { showErrorAlert = false }
            } message: {
                Text(errorMessage ?? "Something went wrong.")
            }
        }
    }
    
    // MARK: - Costco Header
    
    private var costcoHeader: some View {
        VStack(spacing: 8) {
            // Costco Logo
            if UIImage(named: "costco") != nil {
                Image("costco")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(height: 50)
            } else {
                // Fallback text logo styled like Costco
                HStack(spacing: 0) {
                    Text("COSTCO")
                        .font(.system(size: 32, weight: .black))
                        .foregroundColor(CostcoColors.red)
                    Text(" WHOLESALE")
                        .font(.system(size: 14, weight: .bold))
                        .foregroundColor(CostcoColors.blue)
                        .offset(y: 6)
                }
            }
            
            // Store info
            Text("Signal Hill #424")
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .padding(.vertical, 8)
    }
    
    // MARK: - Progress Card
    
    private var progressCard: some View {
        VStack(spacing: 16) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Today's Progress")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    
                    HStack(alignment: .firstTextBaseline, spacing: 4) {
                        Text("\(completedCount)")
                            .font(.system(size: 42, weight: .bold, design: .rounded))
                        Text("of \(todaysReceipts.count)")
                            .font(.title3)
                            .foregroundColor(.secondary)
                    }
                }
                
                Spacer()
                
                // Circular Progress Ring
                ZStack {
                    Circle()
                        .stroke(Color.gray.opacity(0.2), lineWidth: 8)
                    
                    Circle()
                        .trim(from: 0, to: progressValue)
                        .stroke(
                            progressColor,
                            style: StrokeStyle(lineWidth: 8, lineCap: .round)
                        )
                        .rotationEffect(.degrees(-90))
                        .animation(.easeOut(duration: 0.5), value: progressValue)
                    
                    // Percentage or checkmark
                    if progressValue >= 1.0 {
                        Image(systemName: "checkmark")
                            .font(.title2)
                            .fontWeight(.bold)
                            .foregroundColor(.green)
                    } else {
                        Text("\(Int(progressValue * 100))%")
                            .font(.caption)
                            .fontWeight(.semibold)
                            .foregroundColor(.secondary)
                    }
                }
                .frame(width: 64, height: 64)
            }
            
            // Status Message
            HStack(spacing: 8) {
                Image(systemName: statusIcon)
                    .foregroundColor(statusColor)
                
                Text(statusMessage)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                
                Spacer()
                
                if hasIssues {
                    HStack(spacing: 4) {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .foregroundColor(.orange)
                        Text("Issues found")
                            .font(.caption)
                            .foregroundColor(.orange)
                    }
                }
            }
        }
        .padding(20)
        .background(Color(.systemBackground))
        .cornerRadius(16)
        .shadow(color: .black.opacity(0.05), radius: 10, y: 2)
    }
    
    private var progressValue: CGFloat {
        guard todaysReceipts.count > 0 else { return 0 }
        return CGFloat(completedCount) / CGFloat(todaysReceipts.count)
    }
    
    private var progressColor: Color {
        if todaysReceipts.isEmpty { return .gray }
        if completedCount == todaysReceipts.count { return .green }
        if completedCount > 0 { return CostcoColors.blue }
        return .gray
    }
    
    private var statusIcon: String {
        if todaysReceipts.isEmpty { return "clock" }
        if completedCount == todaysReceipts.count { return "checkmark.circle.fill" }
        if completedCount > 0 { return "arrow.triangle.2.circlepath" }
        return "clock"
    }
    
    private var statusColor: Color {
        if todaysReceipts.isEmpty { return .gray }
        if completedCount == todaysReceipts.count { return .green }
        return CostcoColors.blue
    }
    
    private var statusMessage: String {
        if todaysReceipts.isEmpty { return "No receipts scanned yet today" }
        if completedCount == todaysReceipts.count { return "All audits complete!" }
        let remaining = todaysReceipts.count - completedCount
        return "\(remaining) audit\(remaining == 1 ? "" : "s") remaining"
    }
    
    // MARK: - Scan Button
    
    private var scanButton: some View {
        Button {
            showingCamera = true
            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
        } label: {
            HStack(spacing: 14) {
                Image(systemName: "camera.viewfinder")
                    .font(.title2)
                Text("Scan Receipt")
                    .font(.title3)
                    .fontWeight(.semibold)
            }
            .foregroundColor(.white)
            .frame(maxWidth: .infinity)
            .frame(height: 60)
            .background(
                LinearGradient(
                    colors: [CostcoColors.red, CostcoColors.red.opacity(0.85)],
                    startPoint: .leading,
                    endPoint: .trailing
                )
            )
            .cornerRadius(16)
            .shadow(color: CostcoColors.red.opacity(0.3), radius: 8, y: 4)
        }
        .buttonStyle(.plain)
        .accessibilityLabel("Scan a receipt")
        .accessibilityHint("Opens the camera to capture a receipt")
    }
    
    // MARK: - Recent Audits Section
    
    private var recentAuditsSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Recent Scans")
                    .font(.headline)
                    .foregroundColor(.primary)
                
                Spacer()
                
                if todaysReceipts.count > 3 {
                    NavigationLink {
                        ReceiptsListView()
                    } label: {
                        Text("See All")
                            .font(.subheadline)
                            .foregroundColor(.blue)
                    }
                }
            }
            
            VStack(spacing: 8) {
                ForEach(todaysReceipts.prefix(3)) { receipt in
                    NavigationLink {
                        // Navigate to quick audit for this receipt
                        QuickAuditWrapper(receipt: receipt)
                    } label: {
                        RecentAuditRow(receipt: receipt)
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .padding(16)
        .background(Color(.systemBackground))
        .cornerRadius(16)
    }
    
    // MARK: - Export Button
    
    private var exportButton: some View {
        Button {
            showingExport = true
            UIImpactFeedbackGenerator(style: .light).impactOccurred()
        } label: {
            HStack(spacing: 10) {
                Image(systemName: "square.and.arrow.up")
                Text("Export Today's Audits")
                Spacer()
                Text("\(todaysReceipts.count)")
                    .fontWeight(.semibold)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 4)
                    .background(CostcoColors.blue.opacity(0.2))
                    .cornerRadius(8)
            }
            .font(.subheadline)
            .fontWeight(.medium)
            .foregroundColor(CostcoColors.blue)
            .padding(16)
            .background(CostcoColors.blue.opacity(0.08))
            .cornerRadius(12)
        }
        .accessibilityLabel("Export today's audits to CSV")
    }
    
    // MARK: - Stats Section
    
    private var statsSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Quick Stats")
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            HStack(spacing: 12) {
                StatCard(
                    value: "\(allReceipts.count)",
                    label: "Total Receipts",
                    icon: "doc.text",
                    color: CostcoColors.blue
                )
                
                StatCard(
                    value: "\(todaysReceipts.count)",
                    label: "Today",
                    icon: "calendar",
                    color: .green
                )
                
                let issueCount = allReceipts.filter {
                    ($0.auditItemOvercharge != nil && !$0.auditItemOvercharge!.isEmpty) ||
                    ($0.auditItemUndercharge != nil && !$0.auditItemUndercharge!.isEmpty)
                }.count
                
                StatCard(
                    value: "\(issueCount)",
                    label: "Issues",
                    icon: "exclamationmark.triangle",
                    color: issueCount > 0 ? CostcoColors.red : .gray
                )
            }
        }
    }
    
    // MARK: - Camera Handlers
    
    private func handlePhotoCaptured(_ image: UIImage) {
        showingCamera = false
        isProcessing = true
        
        Task {
            await processReceiptImage(image)
        }
    }
    
    private func processReceiptImage(_ image: UIImage) async {
        do {
            let processedImage = try await Task.detached(priority: .userInitiated) {
                image.downscaled(maxDimension: ReceiptConstants.maxImageDimension)
            }.value
            
            async let textTask = ReceiptTextExtractor.extractText(from: processedImage)
            async let barcodeTask = ReceiptBarcodeDetector.detectBarcode(in: processedImage)
            
            let (rawText, barcodeValue) = try await (textTask, barcodeTask)
            let receiptData = ReceiptTextExtractor.parseReceiptData(from: rawText)
            
            guard let imageData = processedImage.jpegData(compressionQuality: ReceiptConstants.jpegCompression) else {
                throw ReceiptProcessingError.imageProcessingFailed
            }
            
            await MainActor.run {
                savePhotoReceipt(
                    imageData: imageData,
                    rawText: rawText,
                    data: receiptData,
                    barcode: barcodeValue
                )
                isProcessing = false
            }
        } catch {
            await MainActor.run {
                isProcessing = false
                errorMessage = error.localizedDescription
                showErrorAlert = true
            }
        }
    }
    
    private func savePhotoReceipt(
        imageData: Data,
        rawText: String,
        data: ReceiptData,
        barcode: String? = nil
    ) {
        let item = ReceiptItem(imageData: imageData, rawText: rawText)
        
        item.storeName = data.storeName
        item.purchaseDate = data.date
        item.totalAmount = data.total
        item.items = data.items
        item.barcodeValue = barcode
        item.cashierNumber = data.cashierNumber
        item.registerNumber = data.registerNumber
        item.transactionNumber = data.transactionNumber
        item.memberID = data.memberID
        item.expectedItemCount = data.expectedItemCount
        item.detailedItems = data.detailedItems.map { StoredLineItem(from: $0) }
        
        modelContext.insert(item)
        
        do {
            try modelContext.save()
            UINotificationFeedbackGenerator().notificationOccurred(.success)
            showSuccessToast()
        } catch {
            errorMessage = "Failed to save receipt: \(error.localizedDescription)"
            showErrorAlert = true
        }
    }
    
    private func showSuccessToast() {
        showSuccessMessage = true
        Task {
            try? await Task.sleep(for: .seconds(ReceiptConstants.toastDuration))
            await MainActor.run {
                showSuccessMessage = false
            }
        }
    }
}

// MARK: - Supporting Views

struct RecentAuditRow: View {
    let receipt: ReceiptItem
    
    private var statusColor: Color {
        if receipt.auditCompleted {
            if (receipt.auditItemOvercharge != nil && !receipt.auditItemOvercharge!.isEmpty) ||
               (receipt.auditItemUndercharge != nil && !receipt.auditItemUndercharge!.isEmpty) {
                return .orange
            }
            return .green
        }
        return .gray
    }
    
    private var statusText: String {
        if receipt.auditCompleted {
            if receipt.auditItemOvercharge != nil && !receipt.auditItemOvercharge!.isEmpty {
                return "Overcharge"
            }
            if receipt.auditItemUndercharge != nil && !receipt.auditItemUndercharge!.isEmpty {
                return "Undercharge"
            }
            return "Complete"
        }
        return "Pending"
    }
    
    private var formattedTime: String {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        return formatter.string(from: receipt.purchaseDate ?? receipt.timestamp)
    }
    
    var body: some View {
        HStack(spacing: 12) {
            // Status indicator
            Circle()
                .fill(statusColor)
                .frame(width: 10, height: 10)
            
            // Info
            VStack(alignment: .leading, spacing: 2) {
                HStack {
                    if let register = receipt.registerNumber {
                        Text("Reg \(register)")
                            .font(.subheadline)
                            .fontWeight(.medium)
                    }
                    
                    if let transaction = receipt.transactionNumber {
                        Text("• #\(transaction)")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                }
                
                HStack(spacing: 8) {
                    Text(formattedTime)
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    if let total = receipt.totalAmount {
                        Text(String(format: "$%.2f", total))
                            .font(.caption)
                            .fontWeight(.medium)
                            .foregroundColor(.green)
                    }
                }
            }
            
            Spacer()
            
            // Status badge
            Text(statusText)
                .font(.caption2)
                .fontWeight(.medium)
                .foregroundColor(statusColor)
                .padding(.horizontal, 8)
                .padding(.vertical, 4)
                .background(statusColor.opacity(0.12))
                .cornerRadius(6)
            
            Image(systemName: "chevron.right")
                .font(.caption)
                .foregroundColor(.gray)
        }
        .padding(.vertical, 10)
        .padding(.horizontal, 4)
        .contentShape(Rectangle())
    }
}

struct StatCard: View {
    let value: String
    let label: String
    let icon: String
    let color: Color
    
    var body: some View {
        VStack(spacing: 6) {
            Image(systemName: icon)
                .font(.title3)
                .foregroundColor(color)
            
            Text(value)
                .font(.title2)
                .fontWeight(.bold)
            
            Text(label)
                .font(.caption2)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 12)
        .background(Color(.systemBackground))
        .cornerRadius(12)
    }
}

struct SuccessToast: View {
    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: "checkmark.circle.fill")
                .foregroundColor(.white)
            Text("Receipt saved!")
                .foregroundColor(.white)
                .fontWeight(.medium)
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 14)
        .background(CostcoColors.blue)
        .cornerRadius(25)
        .shadow(color: .black.opacity(0.15), radius: 10, y: 5)
        .padding(.bottom, 30)
    }
}

struct ProcessingOverlay: View {
    var body: some View {
        ZStack {
            Color.black.opacity(0.4)
                .ignoresSafeArea()
            
            VStack(spacing: 16) {
                ProgressView()
                    .scaleEffect(1.5)
                    .tint(.white)
                
                Text("Processing receipt...")
                    .font(.subheadline)
                    .foregroundColor(.white)
            }
            .padding(32)
            .background(CostcoColors.darkBlue.opacity(0.95))
            .cornerRadius(20)
        }
    }
}

// MARK: - Quick Audit Wrapper (for navigation)

struct QuickAuditWrapper: View {
    let receipt: ReceiptItem
    @Environment(\.modelContext) private var modelContext
    @Environment(\.dismiss) private var dismiss
    
    @State private var auditData: ReceiptAuditData
    
    init(receipt: ReceiptItem) {
        self.receipt = receipt
        self._auditData = State(initialValue: ReceiptAuditData(receipt: receipt))
    }
    
    var body: some View {
        QuickAuditView(
            auditData: $auditData,
            receipt: receipt,
            onComplete: {
                saveAndComplete()
            },
            onSave: {
                saveAuditData()
            }
        )
        .navigationBarTitleDisplayMode(.inline)
    }
    
    private func saveAuditData() {
        receipt.auditItemOvercharge = auditData.itemOvercharge.isEmpty ? nil : auditData.itemOvercharge
        receipt.auditOverchargeName = auditData.itemOverchargeName.isEmpty ? nil : auditData.itemOverchargeName
        receipt.auditOverchargeCost = auditData.itemOverchargeCost.isEmpty ? nil : auditData.itemOverchargeCost
        receipt.auditItemUndercharge = auditData.itemUndercharge.isEmpty ? nil : auditData.itemUndercharge
        receipt.auditUnderchargeName = auditData.itemUnderchargeName.isEmpty ? nil : auditData.itemUnderchargeName
        receipt.auditUnderchargeCost = auditData.itemUnderchargeCost.isEmpty ? nil : auditData.itemUnderchargeCost
        
        receipt.auditBob = auditData.bob
        receipt.auditThreeTotal = auditData.threeTotal
        receipt.auditPrescan = auditData.prescan
        receipt.auditPrescanMatchesBasket = auditData.prescanMatchesBasket
        
        receipt.auditSecurity = auditData.security.isEmpty ? nil : auditData.security
        receipt.auditCashier = auditData.cashier.isEmpty ? nil : auditData.cashier
        receipt.auditAssistant = auditData.assistant.isEmpty ? nil : auditData.assistant
        receipt.auditSupervisor = auditData.supervisor.isEmpty ? nil : auditData.supervisor
        receipt.auditWeek = auditData.week
        
        try? modelContext.save()
        UINotificationFeedbackGenerator().notificationOccurred(.success)
    }
    
    private func saveAndComplete() {
        saveAuditData()
        receipt.auditCompleted = true
        receipt.auditCompletedDate = Date()
        try? modelContext.save()
        dismiss()
    }
}

// MARK: - UIImage Extension

extension UIImage {
    func downscaled(maxDimension: CGFloat) -> UIImage {
        let size = self.size
        
        if size.width <= maxDimension && size.height <= maxDimension {
            return self
        }
        
        let scale = maxDimension / max(size.width, size.height)
        let newSize = CGSize(width: size.width * scale, height: size.height * scale)
        
        let renderer = UIGraphicsImageRenderer(size: newSize)
        return renderer.image { _ in
            self.draw(in: CGRect(origin: .zero, size: newSize))
        }
    }
}

// MARK: - Preview

#Preview {
    ContentView()
        .modelContainer(for: ReceiptItem.self, inMemory: true)
}
