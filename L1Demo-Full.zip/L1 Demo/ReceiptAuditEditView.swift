//
//  ReceiptAuditEditView.swift
//  L1 Demo
//
//  Enhanced: Pre-fills Costco-specific data (cashier, register, items)
//  Updated: Staff dropdowns matching Google Sheets format
//  Updated: Streamlined quick-entry workflow for overcharge/undercharge
//

import SwiftUI

// MARK: - Editable Line Item Model

struct EditableLineItem: Identifiable {
    let id = UUID()
    var name: String
    var quantity: String
    var cost: String
    
    init(name: String, quantity: String = "1", cost: String = "") {
        self.name = name
        self.quantity = quantity
        self.cost = cost
    }
    
    /// Parse from OCR line like "BANANAS $1.49" or "WAGYU GRIND $19.99"
    init(fromOCRLine line: String) {
        var name = line
        var quantity = "1"
        var cost = ""
        
        // Extract price (e.g., "$19.99" or "19.99" at end)
        if let priceMatch = line.range(of: "\\$?\\d+\\.\\d{2}\\s*$", options: .regularExpression) {
            cost = String(line[priceMatch])
                .replacingOccurrences(of: "$", with: "")
                .trimmingCharacters(in: .whitespaces)
            name = String(line[..<priceMatch.lowerBound]).trimmingCharacters(in: .whitespaces)
        }
        
        // Extract quantity prefix (e.g., "2 @" or "x3")
        if let qtyMatch = name.range(of: "^(\\d+)\\s*[@xX]\\s*", options: .regularExpression) {
            let qtyStr = String(name[qtyMatch]).filter { $0.isNumber }
            if let q = Int(qtyStr), q > 0, q < 100 {
                quantity = qtyStr
            }
            name = String(name[qtyMatch.upperBound...]).trimmingCharacters(in: .whitespaces)
        }
        
        // Clean up
        name = name.trimmingCharacters(in: .whitespacesAndNewlines)
        if name.isEmpty { name = line.trimmingCharacters(in: .whitespacesAndNewlines) }
        
        self.name = name
        self.quantity = quantity
        self.cost = cost
    }
    
    /// Initialize from StoredLineItem (detailed items with prices)
    init(from stored: StoredLineItem) {
        self.name = stored.name
        self.quantity = String(stored.quantity)
        if let price = stored.unitPrice ?? stored.totalPrice {
            self.cost = String(format: "%.2f", price)
        } else {
            self.cost = ""
        }
    }
}

// MARK: - Audit Data Model

struct ReceiptAuditData: Identifiable {
    let id: UUID
    let receiptID: UUID
    
    // Display info
    let receiptTitle: String
    let receiptFormattedDate: String
    let receiptTotal: Double?
    let hasImage: Bool
    let rawText: String?
    let expectedItemCount: Int?
    
    // Editable fields - PRE-FILLED from OCR
    var date: Date
    var register: String
    var ring: String
    var cashierNumber: String
    var bob: Bool
    var threeTotal: Bool
    var prescan: Bool
    var prescanMatchesBasket: Bool
    var itemOvercharge: String
    var itemOverchargeName: String
    var itemOverchargeCost: String
    var itemUndercharge: String
    var itemUnderchargeName: String
    var itemUnderchargeCost: String
    var storeName: String
    var totalAmount: String
    var security: String
    var cashier: String
    var assistant: String
    var supervisor: String
    var week: String
    var memberID: String
    
    // Editable line items
    var lineItems: [EditableLineItem]
    
    init(receipt: ReceiptItem) {
        self.id = receipt.id
        self.receiptID = receipt.id
        
        self.receiptTitle = receipt.displayTitle
        self.receiptFormattedDate = receipt.formattedDate
        self.receiptTotal = receipt.totalAmount
        self.hasImage = receipt.imageData != nil
        self.rawText = receipt.rawText
        
        // Use stored fields first, fall back to parsing raw text
        self.expectedItemCount = receipt.expectedItemCount ?? Self.parseRawText(receipt.rawText).expectedItemCount
        
        // Pre-fill date
        self.date = receipt.purchaseDate ?? Date()
        
        // Pre-fill store name
        self.storeName = receipt.storeName ?? "Costco"
        
        // Pre-fill total
        if let total = receipt.totalAmount {
            self.totalAmount = String(format: "%.2f", total)
        } else {
            self.totalAmount = ""
        }
        
        // Pre-fill Costco-specific fields - prefer stored values
        let parsedData = Self.parseRawText(receipt.rawText)
        self.register = receipt.registerNumber ?? parsedData.register ?? ""
        self.ring = receipt.transactionNumber ?? parsedData.transaction ?? ""
        self.cashierNumber = receipt.cashierNumber ?? parsedData.cashierNumber ?? ""
        self.memberID = receipt.memberID ?? parsedData.memberID ?? ""
        
        // Leave blank - user must manually enter item number if there's an overcharge
        self.itemOvercharge = ""
        self.itemOverchargeName = ""      // ADD THIS
        self.itemOverchargeCost = ""      // ADD THIS
        
        // Pre-fill line items - prefer detailed items with prices
        let detailedItems = receipt.detailedItems
        if !detailedItems.isEmpty {
            self.lineItems = detailedItems.map { EditableLineItem(from: $0) }
        } else if let items = receipt.items, !items.isEmpty {
            self.lineItems = items.map { EditableLineItem(fromOCRLine: $0) }
        } else {
            self.lineItems = []
        }
        
        // Defaults for audit checks
        self.bob = false
        self.threeTotal = false
        self.prescan = false
        self.prescanMatchesBasket = false
        // Load SAVED audit data if it exists, otherwise use defaults
        self.itemOvercharge = receipt.auditItemOvercharge ?? ""
        self.itemOverchargeName = receipt.auditOverchargeName ?? ""
        self.itemOverchargeCost = receipt.auditOverchargeCost ?? ""
        self.itemUndercharge = receipt.auditItemUndercharge ?? ""
        self.itemUnderchargeName = receipt.auditUnderchargeName ?? ""
        self.itemUnderchargeCost = receipt.auditUnderchargeCost ?? ""
        
        self.bob = receipt.auditBob
        self.threeTotal = receipt.auditThreeTotal
        self.prescan = receipt.auditPrescan
        self.prescanMatchesBasket = receipt.auditPrescanMatchesBasket
        
        self.security = receipt.auditSecurity ?? ""
        self.cashier = receipt.auditCashier ?? ""
        self.assistant = receipt.auditAssistant ?? ""
        self.supervisor = receipt.auditSupervisor ?? ""
        // Week calculation
        self.week = receipt.auditWeek ?? StaffConfiguration.currentWeek
    }
    
    // MARK: - Parse Raw Text for Costco Fields
    
    private struct ParsedCostcoData {
        var register: String?
        var transaction: String?
        var cashierNumber: String?
        var cashierName: String?
        var memberID: String?
        var expectedItemCount: Int?
    }
    
    private static func parseRawText(_ rawText: String?) -> ParsedCostcoData {
        guard let text = rawText else { return ParsedCostcoData() }
        
        var data = ParsedCostcoData()
        let lines = text.components(separatedBy: .newlines)
        
        for line in lines {
            if data.register == nil,
               let match = line.range(of: "Trm:?\\s*(\\d+)", options: .regularExpression) {
                let fullMatch = String(line[match])
                data.register = fullMatch.filter { $0.isNumber }
            }
            
            if data.transaction == nil,
               let match = line.range(of: "Trn:?\\s*(\\d+)", options: .regularExpression) {
                let fullMatch = String(line[match])
                data.transaction = fullMatch.filter { $0.isNumber }
            }
            
            if data.cashierNumber == nil,
               let match = line.range(of: "OP#:?\\s*(\\d+)", options: .regularExpression) {
                let fullMatch = String(line[match])
                data.cashierNumber = fullMatch.filter { $0.isNumber }
            }
            
            if data.cashierName == nil,
               let match = line.range(of: "Name:?\\s*([A-Za-z]+)", options: .regularExpression) {
                let fullMatch = String(line[match])
                data.cashierName = fullMatch.replacingOccurrences(of: "Name:", with: "")
                    .replacingOccurrences(of: "Name", with: "")
                    .trimmingCharacters(in: .whitespaces)
            }
            
            if data.memberID == nil,
               let match = line.range(of: "Member\\s+(\\d+)", options: .regularExpression) {
                let fullMatch = String(line[match])
                data.memberID = fullMatch.filter { $0.isNumber }
            }
            
            if data.expectedItemCount == nil {
                let lower = line.lowercased()
                if lower.contains("number of items sold") || lower.contains("items sold") {
                    if let numMatch = line.range(of: "=?\\s*(\\d+)\\s*$", options: .regularExpression) {
                        let numStr = String(line[numMatch]).filter { $0.isNumber }
                        data.expectedItemCount = Int(numStr)
                    }
                }
            }
        }
        
        return data
    }
    // Add to ReceiptAuditData
    mutating func lookupOverchargeDetails() {
        guard !itemOvercharge.isEmpty else { return }
        
        // Search line items for matching item
        if let match = lineItems.first(where: { $0.name.contains(itemOvercharge) }) {
            itemOverchargeName = match.name
            itemOverchargeCost = match.cost
        }
    }

    mutating func lookupUnderchargeDetails() {
        guard !itemUndercharge.isEmpty else { return }
        
        if let match = lineItems.first(where: { $0.name.contains(itemUndercharge) }) {
            itemUnderchargeName = match.name
            itemUnderchargeCost = match.cost
        }
    }
}

// MARK: - Date Helper

enum DateHelper {
    private static let calendar = Calendar.current
    
    static func isToday(_ date: Date) -> Bool {
        calendar.isDateInToday(date)
    }
    
    static var currentWeekNumber: Int {
        calendar.component(.weekOfYear, from: Date())
    }
}

// MARK: - Reusable Form Components

struct TextFieldRow: View {
    let label: String
    @Binding var text: String
    var keyboardType: UIKeyboardType = .default
    var placeholder: String = "Enter"
    
    var body: some View {
        HStack {
            Text(label)
                .foregroundColor(.primary)
            Spacer()
            TextField(placeholder, text: $text)
                .multilineTextAlignment(.trailing)
                .keyboardType(keyboardType)
        }
    }
}

struct CurrencyFieldRow: View {
    let label: String
    @Binding var text: String
    
    var body: some View {
        HStack {
            Text(label)
            Spacer()
            Text("$").foregroundColor(.secondary)
            TextField("0.00", text: $text)
                .multilineTextAlignment(.trailing)
                .keyboardType(.decimalPad)
                .frame(maxWidth: 100)
        }
    }
}

/// Dropdown picker row that matches your Google Sheets format
/// Uses enumerated indices to handle duplicate/empty values safely
struct PickerRow: View {
    let label: String
    @Binding var selection: String
    let options: [String]
    
    var body: some View {
        Picker(label, selection: $selection) {
            ForEach(Array(options.enumerated()), id: \.offset) { index, option in
                Text(option.isEmpty ? "—" : option).tag(option)
            }
        }
    }
}

// MARK: - Line Item Row

struct LineItemRow: View {
    @Binding var item: EditableLineItem
    let onDelete: () -> Void
    
    var body: some View {
        VStack(spacing: 8) {
            TextField("Item name", text: $item.name)
                .font(.body)
            
            HStack {
                HStack {
                    Text("Qty:").font(.caption).foregroundColor(.secondary)
                    TextField("1", text: $item.quantity)
                        .keyboardType(.numberPad)
                        .frame(width: 40)
                        .multilineTextAlignment(.center)
                }
                
                Spacer()
                
                HStack {
                    Text("$").font(.caption).foregroundColor(.secondary)
                    TextField("0.00", text: $item.cost)
                        .keyboardType(.decimalPad)
                        .frame(width: 70)
                        .multilineTextAlignment(.trailing)
                }
            }
            .font(.subheadline)
        }
        .padding(.vertical, 4)
        .swipeActions(edge: .trailing) {
            Button(role: .destructive, action: onDelete) {
                Label("Delete", systemImage: "trash")
            }
        }
    }
}

// MARK: - Receipt Audit Edit View

struct ReceiptAuditEditView: View {
    @Binding var auditData: ReceiptAuditData
    let receipt: ReceiptItem?
    
    @State private var showingImagePreview = false
    @State private var showingRawText = false
    @State private var thumbnailImage: UIImage?
    @State private var showingAddItem = false
    @State private var newItemName = ""
    
    var body: some View {
        Form {
            // PRIORITY SECTION: Quick audit entry at top
            quickAuditSection
            
            receiptPreviewSection
            transactionInfoSection
            auditChecksSection
            lineItemsSection
            itemSummarySection
            staffSection
            weekSection
            debugSection
        }
        .sheet(isPresented: $showingImagePreview) {
            if let receipt = receipt, let image = receipt.uiImage {
                ImagePreviewView(image: image)
            }
        }
        .alert("Add Item", isPresented: $showingAddItem) {
            TextField("Item name", text: $newItemName)
            Button("Cancel", role: .cancel) { newItemName = "" }
            Button("Add") {
                if !newItemName.isEmpty {
                    auditData.lineItems.append(EditableLineItem(name: newItemName))
                    newItemName = ""
                }
            }
        } message: {
            Text("Enter the item name")
        }
    }
    
    // MARK: - Quick Audit Section (Priority - at top)
    
    private var quickAuditSection: some View {
        Section {
            // MARK: Overcharge Item
            // MARK: Overcharge Item
            HStack {
                Image(systemName: "arrow.up.circle.fill")
                    .foregroundColor(.red)
                Text("OVERCHARGE")
                    .font(.subheadline)
                    .fontWeight(.semibold)
                Spacer()
            }
            .padding(.top, 8)

            HStack {
                Text("Item #")
                    .frame(width: 70, alignment: .leading)
                TextField("Item #", text: $auditData.itemOvercharge)
                    .keyboardType(.numberPad)
                    .textFieldStyle(.roundedBorder)
                    .onChange(of: auditData.itemOvercharge) { oldValue, newValue in
                        auditData.lookupOverchargeDetails()
                    }
            }

            HStack {
                Text("Name")  // ✅ ADD THIS FIELD
                    .frame(width: 70, alignment: .leading)
                TextField("Item name", text: $auditData.itemOverchargeName)
                    .textFieldStyle(.roundedBorder)
            }

            HStack {
                Text("Cost")
                    .frame(width: 70, alignment: .leading)
                TextField("0.00", text: $auditData.itemOverchargeCost)
                    .keyboardType(.decimalPad)
                    .textFieldStyle(.roundedBorder)
            }
            
            Divider()
            
            // MARK: Undercharge Item
            HStack {
                Image(systemName: "arrow.down.circle.fill")
                    .foregroundColor(.orange)
                Text("UNDERCHARGE")
                    .font(.subheadline)
                    .fontWeight(.semibold)
                Spacer()
            }
            .padding(.top, 8)
        

            HStack {
                Text("Item #")
                    .frame(width: 70, alignment: .leading)
                TextField("Item #", text: $auditData.itemUndercharge)
                    .keyboardType(.numberPad)
                    .textFieldStyle(.roundedBorder)
                    .onChange(of: auditData.itemUndercharge) { oldValue, newValue in
                        auditData.lookupUnderchargeDetails()
                    }
            }
            
            HStack {
                Text("Name")
                    .frame(width: 70, alignment: .leading)
                TextField("Item name", text: $auditData.itemUnderchargeName)
                    .textFieldStyle(.roundedBorder)
            }
            
            HStack {
                Text("Cost")
                    .frame(width: 70, alignment: .leading)
                TextField("0.00", text: $auditData.itemUnderchargeCost)
                    .keyboardType(.decimalPad)
                    .textFieldStyle(.roundedBorder)
            }
            
            Divider()
            
            // Quick staff selection
            PickerRow(
                label: "Security",
                selection: $auditData.security,
                options: StaffConfiguration.securityNames
            )
            
            PickerRow(
                label: "Supervisor",
                selection: $auditData.supervisor,
                options: StaffConfiguration.supervisorNames
            )
            
        } header: {
            Label("Quick Audit Entry", systemImage: "bolt.fill")
                .foregroundColor(.blue)
        } footer: {
            Text("Enter mismatch item numbers, names, and costs. Other fields are auto-filled from receipt.")
                .font(.caption2)
        }
    }
    
    // MARK: - Receipt Preview Section
    
    private var receiptPreviewSection: some View {
        Section {
            if auditData.hasImage {
                Button { showingImagePreview = true } label: {
                    HStack {
                        if let thumb = thumbnailImage {
                            Image(uiImage: thumb)
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(maxHeight: 100)
                                .cornerRadius(8)
                        } else {
                            ProgressView().frame(height: 60)
                        }
                        
                        Spacer()
                        
                        VStack(alignment: .trailing, spacing: 4) {
                            Text("Tap to view").font(.caption).foregroundColor(.blue)
                            
                            let detected = auditData.lineItems.count
                            if let expected = auditData.expectedItemCount {
                                HStack(spacing: 4) {
                                    Image(systemName: detected == expected ? "checkmark.circle.fill" : "exclamationmark.triangle.fill")
                                        .foregroundColor(detected == expected ? .green : .orange)
                                    Text("\(detected)/\(expected) items")
                                }
                                .font(.caption2)
                            } else {
                                Text("\(detected) items detected")
                                    .font(.caption2)
                                    .foregroundColor(.green)
                            }
                        }
                    }
                }
                .task(priority: .userInitiated) {
                    if thumbnailImage == nil, let receipt = receipt {
                        thumbnailImage = receipt.thumbnail(size: CGSize(width: 200, height: 200))
                    }
                }
            }
            
            TextFieldRow(label: "Store", text: $auditData.storeName, placeholder: "Store name")
            
            if !auditData.memberID.isEmpty {
                HStack {
                    Text("Member ID")
                    Spacer()
                    Text(auditData.memberID)
                        .foregroundColor(.secondary)
                }
            }
        } header: {
            Text("Receipt")
        } footer: {
            Text("Fields are auto-filled from OCR. Verify and correct any errors.")
                .font(.caption2)
        }
    }
    
    // MARK: - Transaction Info Section
    
    private var transactionInfoSection: some View {
        Section("Transaction Info") {
            DatePicker("Date", selection: $auditData.date, displayedComponents: .date)
            TextFieldRow(label: "Register", text: $auditData.register, keyboardType: .numberPad, placeholder: "Trm #")
            TextFieldRow(label: "Ring/Trans#", text: $auditData.ring, keyboardType: .numberPad, placeholder: "Trn #")
            TextFieldRow(label: "Cashier #", text: $auditData.cashierNumber, keyboardType: .numberPad, placeholder: "OP #")
        }
    }
    
    // MARK: - Audit Checks Section
    
    private var auditChecksSection: some View {
        Section("Audit Checks") {
            Toggle("B.O.B", isOn: $auditData.bob)
            Toggle("3/ TOTAL", isOn: $auditData.threeTotal)
            Toggle("PRESCAN", isOn: $auditData.prescan)
            Toggle("PRESCAN # = BASKET #", isOn: $auditData.prescanMatchesBasket)
        }
    }
    
    // MARK: - Line Items Section
    
    private var lineItemsSection: some View {
        Section {
            if auditData.lineItems.isEmpty {
                HStack {
                    Image(systemName: "exclamationmark.triangle")
                        .foregroundColor(.orange)
                    Text("No items detected - add manually")
                        .foregroundColor(.secondary)
                        .italic()
                }
            } else {
                ForEach($auditData.lineItems) { $item in
                    LineItemRow(item: $item) {
                        if let index = auditData.lineItems.firstIndex(where: { $0.id == item.id }) {
                            auditData.lineItems.remove(at: index)
                        }
                    }
                }
                .onDelete { auditData.lineItems.remove(atOffsets: $0) }
                .onMove { auditData.lineItems.move(fromOffsets: $0, toOffset: $1) }
            }
            
            Button {
                showingAddItem = true
            } label: {
                HStack {
                    Image(systemName: "plus.circle.fill").foregroundColor(.green)
                    Text("Add Item")
                }
            }
        } header: {
            HStack {
                Text("Line Items (\(auditData.lineItems.count))")
                
                if let expected = auditData.expectedItemCount, auditData.lineItems.count != expected {
                    Text("• Expected: \(expected)")
                        .foregroundColor(.orange)
                        .font(.caption)
                }
                
                Spacer()
                EditButton().font(.caption)
            }
        } footer: {
            Text("Swipe left to delete. Tap Edit to reorder.")
                .font(.caption2)
        }
    }
    
    // MARK: - Item Summary Section
    
    private var itemSummarySection: some View {
        Section("Totals") {
            CurrencyFieldRow(label: "Total", text: $auditData.totalAmount)
            
            let calcTotal = auditData.lineItems.reduce(0.0) { sum, item in
                let qty = Double(item.quantity) ?? 1
                let cost = Double(item.cost) ?? 0
                return sum + (qty * cost)
            }
            
            if calcTotal > 0 {
                HStack {
                    Text("Calculated Total").foregroundColor(.secondary)
                    Spacer()
                    Text(String(format: "$%.2f", calcTotal))
                        .foregroundColor(.green)
                        .fontWeight(.medium)
                }
                .font(.subheadline)
            }
        }
    }
    
    // MARK: - Staff Section (with dropdowns)
    
    private var staffSection: some View {
        Section("Staff") {
            PickerRow(
                label: "Security",
                selection: $auditData.security,
                options: StaffConfiguration.securityNames
            )
            
            PickerRow(
                label: "Cashier",
                selection: $auditData.cashier,
                options: StaffConfiguration.cashierNames
            )
            
            PickerRow(
                label: "Asst.",
                selection: $auditData.assistant,
                options: StaffConfiguration.assistantNames
            )
            
            PickerRow(
                label: "Supervisor",
                selection: $auditData.supervisor,
                options: StaffConfiguration.supervisorNames
            )
        }
    }
    
    // MARK: - Week Section
    
    private var weekSection: some View {
        Section("Period") {
            PickerRow(
                label: "Week",
                selection: $auditData.week,
                options: StaffConfiguration.weekOptions
            )
        }
    }
    
    // MARK: - Debug Section
    
    private var debugSection: some View {
        Group {
            if let rawText = auditData.rawText, !rawText.isEmpty {
                Section {
                    Button {
                        withAnimation { showingRawText.toggle() }
                    } label: {
                        HStack {
                            Image(systemName: showingRawText ? "chevron.down" : "chevron.right")
                            Text("View Raw OCR Text")
                            Spacer()
                            Text("\(rawText.components(separatedBy: .newlines).count) lines")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                    
                    if showingRawText {
                        Text(rawText)
                            .font(.system(.caption, design: .monospaced))
                            .foregroundColor(.secondary)
                            .textSelection(.enabled)
                    }
                } header: {
                    Text("Debug")
                } footer: {
                    Text("Use this to manually copy item names if OCR missed them.")
                        .font(.caption2)
                }
            }
        }
    }
}

// MARK: - Image Preview View

struct ImagePreviewView: View {
    let image: UIImage
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationStack {
            ScrollView([.horizontal, .vertical]) {
                Image(uiImage: image)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
            }
            .navigationTitle("Receipt Image")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") { dismiss() }
                }
            }
        }
    }
}

// MARK: - Daily Audit Export View
struct DailyAuditExportView: View {
    
    let receipts: [ReceiptItem]
    
    @Environment(\.modelContext) private var modelContext

    @State private var auditDataList: [ReceiptAuditData] = []
    @State private var selectedIndex = 0

    // ✅ Fix A state
    @State private var exportFile: ExportFile?            // drives preview sheet
    @State private var shareURL: URL?                     // drives share sheet content
    @State private var showingExportSheet = false         // drives share sheet presentation

    // Error state
    @State private var showingExportError = false
    @State private var exportErrorMessage = ""

    @State private var isLoading = true
    @State private var showAllReceipts = false

    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            content
                .navigationTitle("Daily Audit Export")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar { toolbarContent }
                .alert("Export Error", isPresented: $showingExportError) {
                    Button("OK") { }
                } message: {
                    Text(exportErrorMessage)
                }
                .onAppear { loadAuditDataSync() }

                // ✅ Preview sheet: cannot open without URL
                .sheet(item: $exportFile) { file in
                    CSVPreviewView(
                        csvURL: file.url,
                        onExport: {
                            // When user taps Export in preview:
                            // store url for share, dismiss preview, then show share sheet
                            shareURL = file.url
                            exportFile = nil
                            showingExportSheet = true
                        },
                        onCancel: {
                            // User cancels preview
                            exportFile = nil
                        }
                    )
                }

                // ✅ Share sheet (after preview)
                .sheet(isPresented: $showingExportSheet, onDismiss: {
                    // Optional cleanup
                    // shareURL = nil
                }) {
                    if let url = shareURL {
                        ShareSheet(activityItems: [url])
                    } else {
                        VStack(spacing: 12) {
                            Text("No export file available.")
                                .font(.headline)
                            Text("Try exporting again.")
                                .foregroundColor(.secondary)
                        }
                        .padding()
                    }
                }
        }
    }

    @ViewBuilder
    private var content: some View {
        if isLoading {
            ProgressView("Loading receipts...")
        } else if auditDataList.isEmpty {
            emptyStateView
        } else {
            VStack(spacing: 0) {
                if auditDataList.count > 1 {
                    receiptTabBar
                }

                if selectedIndex < auditDataList.count {
                    ReceiptAuditEditView(
                        auditData: $auditDataList[selectedIndex],
                        receipt: receiptFor(index: selectedIndex)
                    )
                }
            }
        }
    }

    private var receiptTabBar: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(auditDataList.indices, id: \.self) { index in
                    TabButton(
                        index: index,
                        itemCount: auditDataList[index].lineItems.count,
                        expectedCount: auditDataList[index].expectedItemCount,
                        total: auditDataList[index].receiptTotal,
                        isSelected: index == selectedIndex
                    ) {
                        withAnimation { selectedIndex = index }
                    }
                }
            }
            .padding(.horizontal)
            .padding(.vertical, 8)
        }
        .background(Color(.systemGroupedBackground))
    }

    private var emptyStateView: some View {
        VStack(spacing: 16) {
            Image(systemName: "doc.text.magnifyingglass")
                .font(.system(size: 60))
                .foregroundColor(.gray)

            Text("No receipts for today")
                .font(.title2).fontWeight(.semibold)

            Text("Capture receipts first, or show all")
                .font(.subheadline).foregroundColor(.secondary)

            if receipts.count > 0 {
                Button {
                    showAllReceipts = true
                    loadAuditDataSync()
                } label: {
                    Text("Show All \(receipts.count) Receipts")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding(.horizontal, 24)
                        .padding(.vertical, 12)
                        .background(Color.blue)
                        .cornerRadius(10)
                }
            }
        }
        .padding()
    }
    
    private func saveAuditData() {
        for auditData in auditDataList {
            guard let receipt = receipts.first(where: { $0.id == auditData.receiptID }) else { continue }
            
            // Save audit fields to receipt
            receipt.auditItemOvercharge = auditData.itemOvercharge.isEmpty ? nil : auditData.itemOvercharge
            receipt.auditOverchargeName = auditData.itemOverchargeName.isEmpty ? nil : auditData.itemOverchargeName
            receipt.auditOverchargeCost = auditData.itemOverchargeCost.isEmpty ? nil : auditData.itemOverchargeCost
            receipt.auditItemUndercharge = auditData.itemUndercharge.isEmpty ? nil : auditData.itemUndercharge
            receipt.auditUnderchargeName = auditData.itemUnderchargeName.isEmpty ? nil : auditData.itemUnderchargeName
            receipt.auditUnderchargeCost = auditData.itemUnderchargeCost.isEmpty ? nil : auditData.itemUnderchargeCost
            
            receipt.auditBob = auditData.bob
            receipt.auditThreeTotal = auditData.threeTotal
            receipt.auditPrescan = auditData.prescan
            receipt.auditPrescanMatchesBasket = auditData.prescanMatchesBasket
            
            receipt.auditSecurity = auditData.security.isEmpty ? nil : auditData.security
            receipt.auditCashier = auditData.cashier.isEmpty ? nil : auditData.cashier
            receipt.auditAssistant = auditData.assistant.isEmpty ? nil : auditData.assistant
            receipt.auditSupervisor = auditData.supervisor.isEmpty ? nil : auditData.supervisor
            receipt.auditWeek = auditData.week
            
            receipt.auditCompleted = true
            receipt.auditCompletedDate = Date()
        }
        
        do {
            try modelContext.save()
            print("✅ Audit data saved to \(auditDataList.count) receipts")
        } catch {
            print("❌ Failed to save audit data: \(error)")
        }
    }


    @ToolbarContentBuilder
    private var toolbarContent: some ToolbarContent {
        ToolbarItem(placement: .navigationBarLeading) {
            Button("Cancel") {
                saveAuditData()
                dismiss()
            }
        }
        ToolbarItem(placement: .navigationBarTrailing) {
            Button { exportToCSV() } label: {
                HStack {
                    Image(systemName: "square.and.arrow.up")
                    Text("Export")
                }
            }
            .disabled(auditDataList.isEmpty)
        }
    }

    private func loadAuditDataSync() {
        let filtered: [ReceiptItem] = showAllReceipts
            ? receipts
            : receipts.filter { DateHelper.isToday($0.purchaseDate ?? $0.timestamp) }

        auditDataList = filtered.map { ReceiptAuditData(receipt: $0) }
        selectedIndex = 0
        isLoading = false
    }

    private func receiptFor(index: Int) -> ReceiptItem? {
        guard index < auditDataList.count else { return nil }
        return receipts.first { $0.id == auditDataList[index].receiptID }
    }

    private func exportToCSV() {
        saveAuditData()
        print("📤 [DailyAudit] Export button tapped")
        print("📤 [DailyAudit] Audit data count: \(auditDataList.count)")

        guard !auditDataList.isEmpty else {
            print("❌ [DailyAudit] No audit data to export")
            exportErrorMessage = "No receipts to export"
            showingExportError = true
            return
        }

        // Debug: Print temp directory state before export (your existing helper)
        EditableAuditExportManager.debugTempDirectory()

        do {
            print("📤 [DailyAudit] Calling EditableAuditExportManager.exportToCSV...")
            let url = try EditableAuditExportManager.exportToCSV(auditDataList: auditDataList)

            print("✅ [DailyAudit] Export returned URL: \(url.absoluteString)")
            print("✅ [DailyAudit] File name: \(url.lastPathComponent)")
            print("✅ [DailyAudit] Path: \(url.path)")

            let fileExists = FileManager.default.fileExists(atPath: url.path)
            print("🔍 [DailyAudit] File exists check: \(fileExists)")

            if !fileExists {
                print("❌ [DailyAudit] File does not exist at returned URL!")
                exportErrorMessage = "Export file was not created properly"
                showingExportError = true
                return
            }

            if let attrs = try? FileManager.default.attributesOfItem(atPath: url.path),
               let size = attrs[.size] as? Int64 {
                print("📏 [DailyAudit] File size: \(size) bytes")
                if size == 0 {
                    print("⚠️ [DailyAudit] WARNING: File is empty!")
                }
            }

            // ✅ Fix A: drive preview with an Identifiable wrapper
            shareURL = url
            exportFile = ExportFile(url: url)

            print("📤 [DailyAudit] Showing preview via exportFile (non-nil)")
            UINotificationFeedbackGenerator().notificationOccurred(.success)

        } catch {
            print("❌ [DailyAudit] Export failed: \(error)")
            exportErrorMessage = "Failed to export: \(error.localizedDescription)"
            showingExportError = true
            UINotificationFeedbackGenerator().notificationOccurred(.error)
        }
    }
}


// MARK: - Tab Button

private struct TabButton: View {
    let index: Int
    let itemCount: Int
    let expectedCount: Int?
    let total: Double?
    let isSelected: Bool
    let action: () -> Void
    
    private var hasItemMismatch: Bool {
        if let expected = expectedCount { return itemCount != expected }
        return false
    }
    
    var body: some View {
        Button(action: action) {
            VStack(spacing: 2) {
                Text("Receipt \(index + 1)")
                    .font(.caption)
                    .fontWeight(isSelected ? .semibold : .regular)
                
                HStack(spacing: 2) {
                    if hasItemMismatch {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .font(.system(size: 8))
                            .foregroundColor(isSelected ? .white : .orange)
                    }
                    Text("\(itemCount) items")
                }
                .font(.caption2)
                .foregroundColor(isSelected ? .white.opacity(0.8) : (hasItemMismatch ? .orange : .secondary))
                
                if let total = total {
                    Text(String(format: "$%.2f", total))
                        .font(.caption2)
                        .foregroundColor(isSelected ? .white.opacity(0.8) : .green)
                }
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(isSelected ? Color.blue : Color.gray.opacity(0.2))
            .foregroundColor(isSelected ? .white : .primary)
            .cornerRadius(8)
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Export Manager (Matches Google Sheets Format)

/// Export errors for better debugging
enum EditableExportError: LocalizedError {
    case noData
    case fileCreationFailed(path: String, underlyingError: Error?)
    case verificationFailed(path: String)
    
    var errorDescription: String? {
        switch self {
        case .noData:
            return "No audit data to export"
        case .fileCreationFailed(let path, let error):
            return "Failed to create file at \(path): \(error?.localizedDescription ?? "unknown error")"
        case .verificationFailed(let path):
            return "File verification failed: \(path)"
        }
    }
}

enum EditableAuditExportManager {
    
    // Headers matching your exact Google Sheets format
    private static let headers = [
        "date",
        "Register",
        "Ring",
        "Cashier #",
        "B.O.B (Y/N)",
        "3/ TOTAL (Y/N)",
        "PRESCAN Y/N",
        "PRESCAN # = BASKET # Y/N",
        "ITEM # OVERCHARGE",
        "OVERCHARGE NAME",        // NEW
        "OVERCHARGE COST",        // NEW
        "ITEM # UNDERCHARGE",
        "UNDERCHARGE NAME",       // NEW
        "UNDERCHARGE COST",       // NEW
        "Total",
        "Security",
        "Cashier",
        "Asst.",
        "Supervisor",
        "Week",
        "Member ID"
    ]
    
    private static let dateFormatter: DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = "MM/dd/yyyy"
        return f
    }()
    
    private static let filenameFormatter: DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = "MM-dd-yyyy_HHmmss"
        return f
    }()
    
    /// Debug logging helper
    private static func debugLog(_ message: String, file: String = #file, line: Int = #line) {
        let fileName = (file as NSString).lastPathComponent
        print("📤 [EditableExport] [\(fileName):\(line)] \(message)")
    }
    
    static func exportToCSV(auditDataList: [ReceiptAuditData]) throws -> URL {
        debugLog("🚀 Starting export for \(auditDataList.count) audit records")
        
        guard !auditDataList.isEmpty else {
            debugLog("❌ No audit data to export")
            throw EditableExportError.noData
        }
        
        var lines = [headers.joined(separator: ",")]
        debugLog("📋 Headers: \(headers.count) columns")
        
        var totalRows = 0
        for (index, auditData) in auditDataList.enumerated() {
            debugLog("  Processing audit \(index + 1)")
            
            // Create ONE row per receipt (not one per item)
            // Only include overcharge/undercharge item numbers
            lines.append(createCSVRow(
                from: auditData,
                itemName: "",           // Leave blank - not needed
                quantity: "",           // Leave blank - not needed
                cost: "",              // Leave blank - not needed
                showTotal: true        // Always show total on the single row
            ))
            totalRows += 1
        }
        
        let csvText = lines.joined(separator: "\n") + "\n"
        debugLog("📊 Generated \(totalRows) data rows, \(csvText.count) characters total")
        
        // Use unique filename with timestamp to avoid conflicts
        let dateStr = filenameFormatter.string(from: Date())
        let uniqueID = UUID().uuidString.prefix(6)
        let fileName = "daily_audit_\(dateStr)_\(uniqueID).csv"
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(fileName)
        
        debugLog("📁 Target file: \(fileName)")
        debugLog("📍 Full path: \(url.path)")
        
        // Check temp directory
        let tempDir = FileManager.default.temporaryDirectory
        let tempDirExists = FileManager.default.fileExists(atPath: tempDir.path)
        let tempDirWritable = FileManager.default.isWritableFile(atPath: tempDir.path)
        debugLog("📂 Temp dir exists: \(tempDirExists), writable: \(tempDirWritable)")
        
        do {
            try csvText.write(to: url, atomically: true, encoding: .utf8)
            debugLog("✅ Write completed")
            
            // Verify file was created
            let fileExists = FileManager.default.fileExists(atPath: url.path)
            let fileReadable = FileManager.default.isReadableFile(atPath: url.path)
            
            debugLog("🔍 Verification: exists=\(fileExists), readable=\(fileReadable)")
            
            if let attrs = try? FileManager.default.attributesOfItem(atPath: url.path) {
                let size = attrs[.size] as? Int64 ?? 0
                let created = attrs[.creationDate] as? Date
                debugLog("📏 File size: \(size) bytes")
                if let created = created {
                    debugLog("🕐 Created: \(created)")
                }
                
                if size == 0 {
                    debugLog("⚠️ WARNING: File is empty!")
                }
            }
            
            if !fileExists {
                debugLog("❌ File does not exist after write!")
                throw EditableExportError.verificationFailed(path: url.path)
            }
            
            debugLog("✅ Export successful: \(url.lastPathComponent)")
            return url
            
        } catch let error as EditableExportError {
            throw error
        } catch {
            debugLog("❌ Write error: \(error.localizedDescription)")
            throw EditableExportError.fileCreationFailed(path: url.path, underlyingError: error)
        }
    }
    
    /// List CSV files in temp directory (for debugging)
    static func listTempCSVFiles() -> [String] {
        let tempDir = FileManager.default.temporaryDirectory
        guard let contents = try? FileManager.default.contentsOfDirectory(atPath: tempDir.path) else {
            return []
        }
        return contents.filter { $0.hasSuffix(".csv") }.sorted()
    }
    
    /// Print debug info about temp directory
    static func debugTempDirectory() {
        debugLog("📂 Temp directory contents:")
        for file in listTempCSVFiles() {
            let path = FileManager.default.temporaryDirectory.appendingPathComponent(file).path
            if let attrs = try? FileManager.default.attributesOfItem(atPath: path),
               let size = attrs[.size] as? Int64 {
                debugLog("  - \(file) (\(size) bytes)")
            } else {
                debugLog("  - \(file) (size unknown)")
            }
        }
    }
    
    private static func createCSVRow(from d: ReceiptAuditData, itemName: String, quantity: String, cost: String, showTotal: Bool) -> String {
        [
            dateFormatter.string(from: d.date),                    // date
            esc(d.register),                                       // Register
            esc(d.ring),                                           // Ring
            esc(d.cashierNumber),                                  // Cashier #
            d.bob ? "Y" : "N",                                     // B.O.B (Y/N)
            d.threeTotal ? "Y" : "N",                              // 3/ TOTAL (Y/N)
            d.prescan ? "Y" : "N",                                 // PRESCAN Y/N
            d.prescanMatchesBasket ? "Y" : "N",                    // PRESCAN # = BASKET # Y/N
            esc(d.itemOvercharge),                                 // ITEM # OVERCHARGE
            esc(d.itemOverchargeName),                             // OVERCHARGE NAME (NEW)
            d.itemOverchargeCost.isEmpty ? "" : "$\(d.itemOverchargeCost)", // OVERCHARGE COST (NEW)
            esc(d.itemUndercharge),                                // ITEM # UNDERCHARGE
            esc(d.itemUnderchargeName),                            // UNDERCHARGE NAME (NEW)
            d.itemUnderchargeCost.isEmpty ? "" : "$\(d.itemUnderchargeCost)", // UNDERCHARGE COST (NEW)
            showTotal ? (d.totalAmount.isEmpty ? "" : "$\(d.totalAmount)") : "", // Total
            esc(d.security),                                       // Security
            esc(d.cashier),                                        // Cashier
            esc(d.assistant),                                      // Asst.
            esc(d.supervisor),                                     // Supervisor
            esc(d.week),                                           // Week
            esc(d.memberID)                                        // Member ID
        ].joined(separator: ",")
    }
    
    private static func esc(_ text: String) -> String {
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard t.contains(",") || t.contains("\"") || t.contains("\n") else { return t }
        return "\"\(t.replacingOccurrences(of: "\"", with: "\"\""))\""
    }
}


// MARK: - CalendarCache

final class CalendarCache {
    static let shared = CalendarCache()
    private init() {}
    func isToday(_ date: Date) -> Bool { DateHelper.isToday(date) }
    var currentWeekNumber: Int { DateHelper.currentWeekNumber }
}

#Preview {
    DailyAuditExportView(receipts: [])
}
