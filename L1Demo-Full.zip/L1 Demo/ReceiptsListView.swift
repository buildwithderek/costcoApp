//
//  ReceiptsListView.swift
//  L1 Demo
//
//  REDESIGNED: Improved visual hierarchy and status indicators
//  Costco themed
//

import SwiftUI
import SwiftData

// MARK: - Costco Theme Colors (shared)
#if !COSTCO_LIST_COLORS_DEFINED
enum CostcoBrand {
    static let red = Color(red: 0.89, green: 0.12, blue: 0.17)
    static let blue = Color(red: 0.0, green: 0.32, blue: 0.65)
    static let darkBlue = Color(red: 0.0, green: 0.24, blue: 0.49)
}
#endif

struct ReceiptsListView: View {
    @Query(sort: \ReceiptItem.timestamp, order: .reverse)
    private var receipts: [ReceiptItem]
    
    @Environment(\.modelContext) private var modelContext
    
    // Export state
    @State private var exportURL: URL?
    @State private var showingPreview = false
    @State private var showingExportSheet = false
    @State private var showingExportError = false
    @State private var exportErrorMessage = ""
    
    // Other state
    @State private var showingDailyExport = false
    @State private var todayCount: Int = 0
    @State private var searchText = ""
    
    // Filtered receipts
    private var filteredReceipts: [ReceiptItem] {
        if searchText.isEmpty {
            return receipts
        }
        return receipts.filter { receipt in
            receipt.displayTitle.localizedCaseInsensitiveContains(searchText) ||
            (receipt.registerNumber?.contains(searchText) ?? false) ||
            (receipt.transactionNumber?.contains(searchText) ?? false)
        }
    }
    
    // Grouped receipts by date
    private var groupedReceipts: [(String, [ReceiptItem])] {
        let grouped = Dictionary(grouping: filteredReceipts) { receipt -> String in
            let date = receipt.purchaseDate ?? receipt.timestamp
            if Calendar.current.isDateInToday(date) {
                return "Today"
            } else if Calendar.current.isDateInYesterday(date) {
                return "Yesterday"
            } else {
                let formatter = DateFormatter()
                formatter.dateStyle = .medium
                return formatter.string(from: date)
            }
        }
        
        // Sort by date (Today first)
        return grouped.sorted { lhs, rhs in
            if lhs.key == "Today" { return true }
            if rhs.key == "Today" { return false }
            if lhs.key == "Yesterday" { return true }
            if rhs.key == "Yesterday" { return false }
            return lhs.key > rhs.key
        }
    }

    var body: some View {
        Group {
            if receipts.isEmpty {
                emptyStateView
            } else {
                receiptsList
            }
        }
        .navigationTitle("All Receipts")
        .searchable(text: $searchText, prompt: "Search receipts")
        .sheet(isPresented: $showingDailyExport) {
            DailyAuditExportView(receipts: receipts)
        }
        .alert("Export Error", isPresented: $showingExportError) {
            Button("OK") { }
        } message: {
            Text(exportErrorMessage)
        }
        .csvExportFlow(
            csvURL: $exportURL,
            showPreview: $showingPreview,
            showShareSheet: $showingExportSheet
        )
        .task {
            todayCount = calculateTodayCount()
        }
        .onChange(of: receipts.count) { _, _ in
            todayCount = calculateTodayCount()
        }
    }
    
    // MARK: - Subviews
    
    private var receiptsList: some View {
        List {
            // Quick Actions Section
            Section {
                // Daily Export Card
                DailyExportCard(todayCount: todayCount) {
                    showingDailyExport = true
                }
            }
            
            // Summary Stats
            Section {
                SummaryStatsRow(receipts: receipts)
            }
            
            // Grouped Receipts
            ForEach(groupedReceipts, id: \.0) { dateGroup, groupReceipts in
                Section {
                    ForEach(groupReceipts) { receipt in
                        NavigationLink(destination: QuickAuditWrapper(receipt: receipt)) {
                            EnhancedReceiptRow(receipt: receipt)
                        }
                        .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                            Button(role: .destructive) {
                                deleteReceipt(receipt)
                            } label: {
                                Label("Delete", systemImage: "trash")
                            }
                            
                            Button {
                                exportSingleReceipt(receipt)
                            } label: {
                                Label("Export", systemImage: "square.and.arrow.up")
                            }
                            .tint(.blue)
                        }
                    }
                } header: {
                    HStack {
                        Text(dateGroup)
                        Spacer()
                        Text("\(groupReceipts.count)")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
            }
        }
        .listStyle(.insetGrouped)
    }
    
    private var emptyStateView: some View {
        VStack(spacing: 20) {
            Image(systemName: "doc.text.magnifyingglass")
                .font(.system(size: 64))
                .foregroundColor(.gray.opacity(0.5))
            
            VStack(spacing: 8) {
                Text("No Receipts Yet")
                    .font(.title2)
                    .fontWeight(.semibold)
                
                Text("Scan your first receipt to get started")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(.systemGroupedBackground))
    }
    
    @ToolbarContentBuilder
    private var toolbarContent: some ToolbarContent {
        if !receipts.isEmpty {
            ToolbarItem(placement: .navigationBarTrailing) {
                Menu {
                    Button {
                        showingDailyExport = true
                    } label: {
                        Label("Daily Audit Export", systemImage: "calendar.badge.clock")
                    }
                    
                    Divider()
                    
                } label: {
                    Image(systemName: "ellipsis.circle")
                }
            }
        }
    }
    
    // MARK: - Helper Methods
    
    private func calculateTodayCount() -> Int {
        receipts.filter { receipt in
            let date = receipt.purchaseDate ?? receipt.timestamp
            return CalendarCache.shared.isToday(date)
        }.count
    }
    
    private func exportAllReceipts() {
        do {
            let url = try AuditExportManager.exportToCSV(receipts: receipts)
            exportURL = url
            showingPreview = true
            UINotificationFeedbackGenerator().notificationOccurred(.success)
        } catch {
            exportErrorMessage = "Failed to export receipts: \(error.localizedDescription)"
            showingExportError = true
            UINotificationFeedbackGenerator().notificationOccurred(.error)
        }
    }
    
    private func exportSingleReceipt(_ receipt: ReceiptItem) {
        do {
            let url = try AuditExportManager.exportReceiptToCSV(receipt)
            exportURL = url
            showingPreview = true
            UINotificationFeedbackGenerator().notificationOccurred(.success)
        } catch {
            exportErrorMessage = "Failed to export receipt: \(error.localizedDescription)"
            showingExportError = true
            UINotificationFeedbackGenerator().notificationOccurred(.error)
        }
    }
    
    private func deleteReceipt(_ receipt: ReceiptItem) {
        modelContext.delete(receipt)
        try? modelContext.save()
        UINotificationFeedbackGenerator().notificationOccurred(.success)
    }
}

// MARK: - Daily Export Card

private struct DailyExportCard: View {
    let todayCount: Int
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 14) {
                // Icon
                ZStack {
                    RoundedRectangle(cornerRadius: 10)
                        .fill(LinearGradient(
                            colors: [CostcoBrand.red, CostcoBrand.red.opacity(0.8)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ))
                        .frame(width: 44, height: 44)
                    
                    Image(systemName: "calendar.badge.clock")
                        .font(.title3)
                        .foregroundColor(.white)
                }
                
                // Text
                VStack(alignment: .leading, spacing: 2) {
                    Text("Daily Audit Export")
                        .font(.headline)
                        .foregroundColor(.primary)
                    
                    Text("Review & export today's receipts")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                Spacer()
                
                // Count Badge
                if todayCount > 0 {
                    Text("\(todayCount)")
                        .font(.subheadline)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 6)
                        .background(CostcoBrand.blue)
                        .cornerRadius(14)
                } else {
                    Text("0")
                        .font(.subheadline)
                        .fontWeight(.medium)
                        .foregroundColor(.secondary)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 6)
                        .background(Color.gray.opacity(0.2))
                        .cornerRadius(14)
                }
                
                Image(systemName: "chevron.right")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            .padding(.vertical, 4)
        }
    }
}

// MARK: - Summary Stats Row

private struct SummaryStatsRow: View {
    let receipts: [ReceiptItem]
    
    private var completedCount: Int {
        receipts.filter { $0.auditCompleted }.count
    }
    
    private var issueCount: Int {
        receipts.filter {
            ($0.auditItemOvercharge != nil && !$0.auditItemOvercharge!.isEmpty) ||
            ($0.auditItemUndercharge != nil && !$0.auditItemUndercharge!.isEmpty)
        }.count
    }
    
    private var totalValue: Double {
        receipts.compactMap { $0.totalAmount }.reduce(0, +)
    }
    
    var body: some View {
        HStack(spacing: 0) {
            StatItem(
                value: "\(receipts.count)",
                label: "Total",
                color: CostcoBrand.blue
            )
            
            Divider()
                .frame(height: 30)
            
            StatItem(
                value: "\(completedCount)",
                label: "Completed",
                color: .green
            )
            
            Divider()
                .frame(height: 30)
            
            StatItem(
                value: "\(issueCount)",
                label: "Issues",
                color: issueCount > 0 ? CostcoBrand.red : .gray
            )
            
            Divider()
                .frame(height: 30)
            
            StatItem(
                value: String(format: "$%.0f", totalValue),
                label: "Value",
                color: .green
            )
        }
        .padding(.vertical, 4)
    }
}

private struct StatItem: View {
    let value: String
    let label: String
    let color: Color
    
    var body: some View {
        VStack(spacing: 2) {
            Text(value)
                .font(.headline)
                .foregroundColor(color)
            Text(label)
                .font(.caption2)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
    }
}

// MARK: - Enhanced Receipt Row

private struct EnhancedReceiptRow: View {
    let receipt: ReceiptItem
    
    @State private var thumbnail: UIImage?
    
    private var statusColor: Color {
        if receipt.auditCompleted {
            if hasIssues { return .orange }
            return .green
        }
        return .gray
    }
    
    private var hasIssues: Bool {
        (receipt.auditItemOvercharge != nil && !receipt.auditItemOvercharge!.isEmpty) ||
        (receipt.auditItemUndercharge != nil && !receipt.auditItemUndercharge!.isEmpty)
    }
    
    private var statusText: String {
        if receipt.auditCompleted {
            if receipt.auditItemOvercharge != nil && !receipt.auditItemOvercharge!.isEmpty {
                return "Overcharge"
            }
            if receipt.auditItemUndercharge != nil && !receipt.auditItemUndercharge!.isEmpty {
                return "Undercharge"
            }
            return "Complete"
        }
        return "Pending"
    }
    
    private var formattedTime: String {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        return formatter.string(from: receipt.purchaseDate ?? receipt.timestamp)
    }

    var body: some View {
        HStack(spacing: 12) {
            // Thumbnail
            ZStack {
                if let thumbnail = thumbnail {
                    Image(uiImage: thumbnail)
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: 50, height: 50)
                        .cornerRadius(8)
                } else {
                    RoundedRectangle(cornerRadius: 8)
                        .fill(Color.gray.opacity(0.1))
                        .frame(width: 50, height: 50)
                        .overlay(
                            Image(systemName: "doc.text")
                                .foregroundColor(.gray)
                        )
                }
                
                // Status dot overlay
                Circle()
                    .fill(statusColor)
                    .frame(width: 12, height: 12)
                    .overlay(
                        Circle()
                            .stroke(Color(.systemBackground), lineWidth: 2)
                    )
                    .offset(x: 20, y: -20)
            }
            .task(priority: .background) {
                thumbnail = receipt.thumbnail(size: CGSize(width: 100, height: 100))
            }

            // Info
            VStack(alignment: .leading, spacing: 4) {
                // Transaction info
                HStack(spacing: 4) {
                    if let register = receipt.registerNumber {
                        Text("Reg \(register)")
                            .font(.subheadline)
                            .fontWeight(.medium)
                    }
                    
                    if let transaction = receipt.transactionNumber {
                        Text("•")
                            .foregroundColor(.secondary)
                        Text("#\(transaction)")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                }
                
                // Time and total
                HStack(spacing: 8) {
                    Text(formattedTime)
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    if let total = receipt.totalAmount {
                        Text(String(format: "$%.2f", total))
                            .font(.caption)
                            .fontWeight(.semibold)
                            .foregroundColor(.green)
                    }
                    
                    // Item count
                    let itemCount = receipt.detailedItems.isEmpty ?
                        (receipt.items?.count ?? 0) :
                        receipt.detailedItems.count
                    
                    if itemCount > 0 {
                        Text("• \(itemCount) items")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
            }

            Spacer()
            
            // Status badge
            Text(statusText)
                .font(.caption2)
                .fontWeight(.medium)
                .foregroundColor(statusColor)
                .padding(.horizontal, 8)
                .padding(.vertical, 4)
                .background(statusColor.opacity(0.12))
                .cornerRadius(6)
        }
        .padding(.vertical, 4)
    }
}

// MARK: - Preview

#Preview {
    NavigationStack {
        ReceiptsListView()
    }
    .modelContainer(for: ReceiptItem.self, inMemory: true)
}
