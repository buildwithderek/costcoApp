//
//  ZipExportManager.swift
//  L1 Demo
//
//  Exports audit data as ZIP containing CSV + receipt images
//  Structure: audit_export.zip
//            ├── audit_data.csv
//            └── images/
//                ├── Reg12_Txn4567.jpg
//                └── ...
//

import Foundation
import UIKit


// MARK: - ZIP Export Manager

enum ZipExportManager {
    
    // MARK: - Headers (same as EditableAuditExportManager + Image column)
    
    private static let headers = [
        "date",
        "Register",
        "Ring",
        "Cashier #",
        "B.O.B (Y/N)",
        "3/ TOTAL (Y/N)",
        "PRESCAN Y/N",
        "PRESCAN # = BASKET # Y/N",
        "ITEM # OVERCHARGE",
        "OVERCHARGE NAME",
        "OVERCHARGE COST",
        "ITEM # UNDERCHARGE",
        "UNDERCHARGE NAME",
        "UNDERCHARGE COST",
        "Total",
        "Security",
        "Cashier",
        "Asst.",
        "Supervisor",
        "Week",
        "Member ID",
        "Image File"  // NEW: Reference to image in images/ folder
    ]
    
    private static let dateFormatter: DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = "MM/dd/yyyy"
        return f
    }()
    
    private static let filenameFormatter: DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = "MM-dd-yyyy_HHmmss"
        return f
    }()
    
    private static func debugLog(_ message: String) {
        print("📦 [ZipExport] \(message)")
    }
    
    // MARK: - Export with Images
    
    /// Export audit data + images as a ZIP file
    /// - Parameters:
    ///   - auditDataList: Array of ReceiptAuditData to export
    ///   - receipts: Array of ReceiptItem containing images (matched by receiptID)
    /// - Returns: URL to the created ZIP file
    static func exportWithImages(
        auditDataList: [ReceiptAuditData],
        receipts: [ReceiptItem]
    ) throws -> URL {
        debugLog("🚀 Starting ZIP export for \(auditDataList.count) audits")
        
        guard !auditDataList.isEmpty else {
            throw ZipExportError.noData
        }
        
        // Create temp directory for staging
        let dateStr = filenameFormatter.string(from: Date())
        let uniqueID = UUID().uuidString.prefix(6)
        let stagingDirName = "audit_export_\(dateStr)_\(uniqueID)"
        let stagingDir = FileManager.default.temporaryDirectory.appendingPathComponent(stagingDirName)
        let imagesDir = stagingDir.appendingPathComponent("images")
        
        // Clean up any existing staging dir
        try? FileManager.default.removeItem(at: stagingDir)
        
        // Create directories
        try FileManager.default.createDirectory(at: imagesDir, withIntermediateDirectories: true)
        debugLog("📁 Created staging directory: \(stagingDirName)")
        
        // Build receipt lookup by ID
        let receiptLookup = Dictionary(uniqueKeysWithValues: receipts.map { ($0.id, $0) })
        
        // Process each audit and collect image filenames
        var csvLines = [headers.joined(separator: ",")]
        var imageCount = 0
        
        for auditData in auditDataList {
            // Generate image filename
            let imageFileName = generateImageFileName(for: auditData)
            
            // Try to save image
            var savedImageName = ""
            if let receipt = receiptLookup[auditData.receiptID],
               let imageData = receipt.imageData,
               let image = UIImage(data: imageData) {
                
                // Compress and save as JPEG
                if let jpegData = image.jpegData(compressionQuality: 0.7) {
                    let imagePath = imagesDir.appendingPathComponent(imageFileName)
                    do {
                        try jpegData.write(to: imagePath)
                        savedImageName = "images/\(imageFileName)"
                        imageCount += 1
                        debugLog("  ✅ Saved image: \(imageFileName)")
                    } catch {
                        debugLog("  ⚠️ Failed to save image: \(error.localizedDescription)")
                    }
                }
            }
            
            // Create CSV row with image reference
            let row = createCSVRow(from: auditData, imageFile: savedImageName)
            csvLines.append(row)
        }
        
        debugLog("📊 Generated \(csvLines.count - 1) CSV rows, \(imageCount) images")
        
        // Write CSV file
        let csvText = csvLines.joined(separator: "\n") + "\n"
        let csvPath = stagingDir.appendingPathComponent("audit_data.csv")
        try csvText.write(to: csvPath, atomically: true, encoding: .utf8)
        debugLog("✅ CSV written: audit_data.csv")
        
        // Create ZIP file
        let zipFileName = "audit_export_\(dateStr)_\(uniqueID).zip"
        let zipPath = FileManager.default.temporaryDirectory.appendingPathComponent(zipFileName)
        
        // Remove existing ZIP if present
        try? FileManager.default.removeItem(at: zipPath)
        
        // Create the ZIP archive
        try createZipArchive(from: stagingDir, to: zipPath)
        debugLog("✅ ZIP created: \(zipFileName)")
        
        // Clean up staging directory
        try? FileManager.default.removeItem(at: stagingDir)
        
        // Verify ZIP exists
        guard FileManager.default.fileExists(atPath: zipPath.path) else {
            throw ZipExportError.zipCreationFailed
        }
        
        if let attrs = try? FileManager.default.attributesOfItem(atPath: zipPath.path),
           let size = attrs[.size] as? Int64 {
            debugLog("📦 ZIP size: \(ByteCountFormatter.string(fromByteCount: size, countStyle: .file))")
        }
        
        return zipPath
    }
    
    // MARK: - ZIP Creation (Manual implementation without external dependency)
    
    private static func createZipArchive(from sourceDir: URL, to zipPath: URL) throws {
        // Use built-in compression if available (iOS 16+)
        if #available(iOS 16.0, *) {
            try createZipWithFileManager(from: sourceDir, to: zipPath)
        } else {
            // Fallback: Use NSFileCoordinator approach or shell out to zip
            try createZipWithCoordinator(from: sourceDir, to: zipPath)
        }
    }
    
    @available(iOS 16.0, *)
    private static func createZipWithFileManager(from sourceDir: URL, to zipPath: URL) throws {
        // iOS 16+ has built-in ZIP support
        let coordinator = NSFileCoordinator()
        var error: NSError?
        
        coordinator.coordinate(readingItemAt: sourceDir, options: .forUploading, error: &error) { zipURL in
            do {
                try FileManager.default.copyItem(at: zipURL, to: zipPath)
            } catch {
                debugLog("❌ ZIP copy failed: \(error)")
            }
        }
        
        if let error = error {
            throw error
        }
    }
    
    private static func createZipWithCoordinator(from sourceDir: URL, to zipPath: URL) throws {
        // Fallback for iOS < 16: Use NSFileCoordinator
        let coordinator = NSFileCoordinator()
        var coordinatorError: NSError?
        var success = false
        
        coordinator.coordinate(readingItemAt: sourceDir, options: .forUploading, error: &coordinatorError) { tempZipURL in
            do {
                try FileManager.default.copyItem(at: tempZipURL, to: zipPath)
                success = true
            } catch {
                debugLog("❌ Failed to copy ZIP: \(error)")
            }
        }
        
        if let error = coordinatorError {
            throw error
        }
        
        if !success {
            throw ZipExportError.zipCreationFailed
        }
    }
    
    // MARK: - Helpers
    
    private static func generateImageFileName(for auditData: ReceiptAuditData) -> String {
        let register = auditData.register.isEmpty ? "Unknown" : auditData.register
        let ring = auditData.ring.isEmpty ? "0" : auditData.ring
        let dateStr = dateFormatter.string(from: auditData.date).replacingOccurrences(of: "/", with: "-")
        
        // Clean filename of invalid characters
        let fileName = "Reg\(register)_Txn\(ring)_\(dateStr).jpg"
        return fileName.replacingOccurrences(of: " ", with: "_")
    }
    
    private static func createCSVRow(from d: ReceiptAuditData, imageFile: String) -> String {
        [
            dateFormatter.string(from: d.date),
            esc(d.register),
            esc(d.ring),
            esc(d.cashierNumber),
            d.bob ? "Y" : "N",
            d.threeTotal ? "Y" : "N",
            d.prescan ? "Y" : "N",
            d.prescanMatchesBasket ? "Y" : "N",
            esc(d.itemOvercharge),
            esc(d.itemOverchargeName),
            d.itemOverchargeCost.isEmpty ? "" : "$\(d.itemOverchargeCost)",
            esc(d.itemUndercharge),
            esc(d.itemUnderchargeName),
            d.itemUnderchargeCost.isEmpty ? "" : "$\(d.itemUnderchargeCost)",
            d.totalAmount.isEmpty ? "" : "$\(d.totalAmount)",
            esc(d.security),
            esc(d.cashier),
            esc(d.assistant),
            esc(d.supervisor),
            esc(d.week),
            esc(d.memberID),
            esc(imageFile)
        ].joined(separator: ",")
    }
    
    private static func esc(_ text: String) -> String {
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard t.contains(",") || t.contains("\"") || t.contains("\n") else { return t }
        return "\"\(t.replacingOccurrences(of: "\"", with: "\"\""))\""
    }
}

// MARK: - Errors

enum ZipExportError: LocalizedError {
    case noData
    case imageExportFailed
    case zipCreationFailed
    case verificationFailed
    
    var errorDescription: String? {
        switch self {
        case .noData:
            return "No audit data to export"
        case .imageExportFailed:
            return "Failed to export receipt images"
        case .zipCreationFailed:
            return "Failed to create ZIP archive"
        case .verificationFailed:
            return "ZIP file verification failed"
        }
    }
}
