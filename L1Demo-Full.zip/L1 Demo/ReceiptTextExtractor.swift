//
//  ReceiptTextExtractor.swift
//  L1 Demo
//
//  Created by Derek Punaro on 10/3/25
//  Updated: Stricter Costco receipt parsing - only captures actual items with prices
//

import UIKit
import Vision

// MARK: - Receipt Text Extractor

final class ReceiptTextExtractor {

    // MARK: - Regex Patterns

    /// Money pattern: $5.99 or 5.99
    private static let moneyRegex = try! NSRegularExpression(
        pattern: "\\$?([0-9]+\\.[0-9]{2})",
        options: []
    )

    /// Date pattern: MM/DD/YYYY or MM-DD-YYYY
    private static let dateRegex = try! NSRegularExpression(
        pattern: "(\\d{1,2})[/-](\\d{1,2})[/-](\\d{2,4})",
        options: []
    )

    /// Costco item line: E + code + name + price
    /// Example: "E 30669 BANANAS 1.49"
    /// The 'E' indicates a taxable item
    private static let costcoEItemRegex = try! NSRegularExpression(
        pattern: "^E\\s+(\\d{4,7})\\s+(.+?)\\s+(\\d+\\.\\d{2})\\s*$",
        options: [.caseInsensitive]
    )
    
    /// Costco item line: code + name + price (no E prefix, non-taxable)
    /// Example: "1849333 TC MUFFIN 8.99"
    private static let costcoItemRegex = try! NSRegularExpression(
        pattern: "^(\\d{4,7})\\s+([A-Z][A-Z0-9 ]{2,25})\\s+(\\d+\\.\\d{2})\\s*$",
        options: [.caseInsensitive]
    )
    
    /// Costco item with A suffix (alcohol/age-restricted)
    /// Example: "A 123456 WINE 19.99"
    private static let costcoAItemRegex = try! NSRegularExpression(
        pattern: "^A\\s+(\\d{4,7})\\s+(.+?)\\s+(\\d+\\.\\d{2})\\s*$",
        options: [.caseInsensitive]
    )

    /// Quantity line: "2 @ 5.99"
    private static let quantityAtPriceRegex = try! NSRegularExpression(
        pattern: "^(\\d+)\\s*@\\s*\\$?(\\d+\\.\\d{2})\\s*$",
        options: [.caseInsensitive]
    )
    
    /// Coupon line: negative price or "COUPON" keyword
    /// Example: "-3.00" or "INSTANT SAVINGS -3.00"
    private static let couponRegex = try! NSRegularExpression(
        pattern: "(-\\d+\\.\\d{2})|coupon|savings|discount|off\\b",
        options: [.caseInsensitive]
    )

    /// Item count: "TOTAL NUMBER OF ITEMS SOLD = 12"
    private static let itemCountRegex = try! NSRegularExpression(
        pattern: "(?:TOTAL\\s+NUMBER\\s+OF\\s+ITEMS\\s+SOLD\\s*[-=:]?\\s*(\\d+)|Items\\s+Sold:?\\s*(\\d+))",
        options: [.caseInsensitive]
    )

    private static let cashierRegex = try! NSRegularExpression(
        pattern: "OP#:?\\s*(\\d+)",
        options: [.caseInsensitive]
    )

    private static let terminalRegex = try! NSRegularExpression(
        pattern: "Trm:?\\s*(\\d+)",
        options: [.caseInsensitive]
    )

    private static let transactionRegex = try! NSRegularExpression(
        pattern: "Trn:?\\s*(\\d+)",
        options: [.caseInsensitive]
    )

    private static let memberRegex = try! NSRegularExpression(
        pattern: "(?:2D|U1|LX)?\\s*Member\\s+(\\d{10,12})",
        options: [.caseInsensitive]
    )

    // MARK: - Keyword Sets

    private static let totalKeywords: Set<String> = [
        "total", "amount due", "amt due", "grand total"
    ]

    /// Lines containing these are NOT items
    private static let nonItemKeywords: Set<String> = [
        "subtotal", "tax", "change", "balance", "approved",
        "visa", "mastercard", "debit", "credit", "cash",
        "thank", "please", "come again", "welcome",
        "aid:", "seq#", "app#", "tran", "whse:", "trm:", "trn:", "op#",
        "member", "costco", "wholesale", "warehouse",
        "self-checkout", "self checkout", "instacart",
        "refund", "void", "return", "exchange"
    ]

    // MARK: - OCR

    static func extractText(from image: UIImage) async throws -> String {
        guard let cgImage = image.cgImage else {
            throw ExtractionError.invalidImage
        }

        let request = VNRecognizeTextRequest()
        request.recognitionLevel = .accurate
        request.usesLanguageCorrection = true
        request.recognitionLanguages = ["en-US"]

        let handler = VNImageRequestHandler(cgImage: cgImage)
        try handler.perform([request])

        let text = request.results?
            .compactMap { $0.topCandidates(1).first?.string }
            .joined(separator: "\n") ?? ""

        guard !text.isEmpty else {
            throw ExtractionError.noTextFound
        }

        return text
    }

    // MARK: - Main Parsing Entry

    static func parseReceiptData(from text: String) -> ReceiptData {
        let lines = text
            .components(separatedBy: .newlines)
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }

        var data = ReceiptData()
        var allAmounts: [Double] = []

        // MARK: Metadata pass
        for (index, line) in lines.enumerated() {
            let lower = line.lowercased()

            if data.storeName == nil && index < 5 {
                if lower.contains("costco") || lower.contains("wholesale") {
                    data.storeName = "Costco"
                } else if index == 0 {
                    data.storeName = line
                }
            }

            if data.date == nil {
                data.date = extractDate(from: line)
            }

            if let count = extractItemCount(from: line) {
                data.expectedItemCount = count
            }

            if data.cashierNumber == nil {
                data.cashierNumber = extractCashier(from: line)
            }

            if data.registerNumber == nil {
                data.registerNumber = extractTerminal(from: line)
            }

            if data.transactionNumber == nil {
                data.transactionNumber = extractTransaction(from: line)
            }

            if data.memberID == nil {
                data.memberID = extractMember(from: line)
            }

            let amounts = extractAmounts(from: line)
            allAmounts.append(contentsOf: amounts)

            if totalKeywords.contains(where: { lower.contains($0) }),
               !lower.contains("items") {
                data.total = amounts.max()
            }
        }

        // MARK: Item extraction - STRICT parsing
        let detailedItems = extractCostcoItems(from: lines)
        data.detailedItems = detailedItems
        
        // Also populate simple items array for backward compatibility
        data.items = detailedItems.map { item in
            if let price = item.totalPrice ?? item.unitPrice {
                return "\(item.name) $\(String(format: "%.2f", price))"
            }
            return item.name
        }

        if data.total == nil {
            data.total = allAmounts.max()
        }

        return data
    }

    // MARK: - Strict Costco Item Extraction

    private static func extractCostcoItems(from lines: [String]) -> [DetailedLineItem] {
        var results: [DetailedLineItem] = []
        var pendingQuantity: (qty: Int, unitPrice: Double)? = nil
        
        // Find item section bounds
        let (startIndex, endIndex) = findItemSectionBounds(lines)
        let itemSection = Array(lines[startIndex..<endIndex])
        
        for (index, rawLine) in itemSection.enumerated() {
            let line = rawLine.trimmingCharacters(in: .whitespacesAndNewlines)
            
            // Skip non-item lines
            if isNonItemLine(line) { continue }
            
            // Skip coupon/discount lines
            if isCouponLine(line) { continue }
            
            // Check for quantity line: "2 @ 5.99"
            if let qtyMatch = matchQuantityLine(line) {
                pendingQuantity = qtyMatch
                continue
            }
            
            // Try to match item patterns (most specific first)
            var matchedItem: DetailedLineItem? = nil
            
            // Pattern 1: E + code + name + price (taxable item)
            if let item = matchCostcoItem(costcoEItemRegex, line: line) {
                matchedItem = item
            }
            // Pattern 2: A + code + name + price (age-restricted)
            else if let item = matchCostcoItem(costcoAItemRegex, line: line) {
                matchedItem = item
            }
            // Pattern 3: code + name + price (standard)
            else if let item = matchCostcoItem(costcoItemRegex, line: line) {
                matchedItem = item
            }
            
            // If we matched an item, apply pending quantity and add to results
            if var item = matchedItem {
                if let pending = pendingQuantity {
                    item = DetailedLineItem(
                        name: item.name,
                        quantity: pending.qty,
                        unitPrice: pending.unitPrice,
                        totalPrice: item.totalPrice
                    )
                    pendingQuantity = nil
                }
                results.append(item)
            }
        }
        
        return results
    }
    
    /// Find the start and end of the item section
    private static func findItemSectionBounds(_ lines: [String]) -> (start: Int, end: Int) {
        let lower = lines.map { $0.lowercased() }
        
        // Start: After "Member" line (member ID indicates start of transaction)
        var start = 0
        for (i, line) in lower.enumerated() {
            if line.contains("member") && line.contains(where: { $0.isNumber }) {
                start = min(i + 1, lines.count)
                break
            }
        }
        
        // End: Before "Subtotal" or "Total" (whichever comes first)
        var end = lines.count
        for (i, line) in lower.enumerated() where i > start {
            if line.contains("subtotal") ||
               (line.contains("total") && !line.contains("items")) {
                end = i
                break
            }
        }
        
        return (start, end)
    }
    
    /// Check if line is definitely NOT an item
    private static func isNonItemLine(_ line: String) -> Bool {
        let t = line.trimmingCharacters(in: .whitespacesAndNewlines)
        if t.isEmpty { return true }
        if t.count < 3 { return true }
        
        let lower = t.lowercased()
        
        // Contains non-item keywords
        if nonItemKeywords.contains(where: { lower.contains($0) }) {
            return true
        }
        
        // Pure numbers (no letters) - probably a barcode or ID
        let letters = t.filter { $0.isLetter }
        if letters.isEmpty { return true }
        
        // Long number sequences with minimal letters (barcodes, transaction IDs)
        let digits = t.filter { $0.isNumber }
        if digits.count >= 10 && letters.count <= 2 { return true }
        
        return false
    }
    
    /// Check if line is a coupon/discount (negative price)
    private static func isCouponLine(_ line: String) -> Bool {
        let ns = line as NSString
        let range = NSRange(location: 0, length: ns.length)
        return couponRegex.firstMatch(in: line, range: range) != nil
    }
    
    /// Match quantity line like "2 @ 5.99"
    private static func matchQuantityLine(_ line: String) -> (qty: Int, unitPrice: Double)? {
        let ns = line as NSString
        let range = NSRange(location: 0, length: ns.length)
        
        guard let match = quantityAtPriceRegex.firstMatch(in: line, range: range),
              match.numberOfRanges >= 3,
              let qtyRange = Range(match.range(at: 1), in: line),
              let priceRange = Range(match.range(at: 2), in: line),
              let qty = Int(line[qtyRange]),
              let price = Double(line[priceRange])
        else { return nil }
        
        return (qty, price)
    }
    
    /// Match Costco item pattern and extract details
    private static func matchCostcoItem(_ regex: NSRegularExpression, line: String) -> DetailedLineItem? {
        let ns = line as NSString
        let range = NSRange(location: 0, length: ns.length)
        
        guard let match = regex.firstMatch(in: line, range: range),
              match.numberOfRanges >= 4
        else { return nil }
        
        // Extract name (group 2) and price (group 3)
        // Group 1 is the item code
        guard let nameRange = Range(match.range(at: 2), in: line),
              let priceRange = Range(match.range(at: 3), in: line)
        else { return nil }
        
        let name = String(line[nameRange])
            .trimmingCharacters(in: .whitespaces)
            .uppercased()
        
        guard let price = Double(line[priceRange]) else { return nil }
        
        // Validate: name should be at least 2 chars and mostly letters
        let nameLetters = name.filter { $0.isLetter }
        if nameLetters.count < 2 { return nil }
        
        return DetailedLineItem(
            name: name,
            quantity: 1,
            unitPrice: price,
            totalPrice: price
        )
    }

    // MARK: - Field Extractors

    private static func extractAmounts(from text: String) -> [Double] {
        let ns = text as NSString
        let range = NSRange(location: 0, length: ns.length)
        return moneyRegex.matches(in: text, range: range)
            .compactMap {
                Range($0.range(at: 1), in: text)
                    .flatMap { Double(text[$0]) }
            }
    }

    private static func extractDate(from text: String) -> Date? {
        let ns = text as NSString
        let range = NSRange(location: 0, length: ns.length)
        let matches = dateRegex.matches(in: text, range: range)
        let formatter = DateFormatterCache.shared.formatter

        for m in matches {
            if let r = Range(m.range, in: text),
               let d = formatter.date(from: text[r].replacingOccurrences(of: "-", with: "/")) {
                return d
            }
        }
        return nil
    }

    private static func extractItemCount(from text: String) -> Int? {
        let ns = text as NSString
        let range = NSRange(location: 0, length: ns.length)
        let matches = itemCountRegex.matches(in: text, range: range)
        for m in matches {
            for i in 1..<m.numberOfRanges {
                if let r = Range(m.range(at: i), in: text),
                   let n = Int(text[r]) {
                    return n
                }
            }
        }
        return nil
    }

    private static func extractCashier(from text: String) -> String? {
        matchSimple(cashierRegex, text)
    }

    private static func extractTerminal(from text: String) -> String? {
        matchSimple(terminalRegex, text)
    }

    private static func extractTransaction(from text: String) -> String? {
        matchSimple(transactionRegex, text)
    }

    private static func extractMember(from text: String) -> String? {
        matchSimple(memberRegex, text)
    }

    private static func matchSimple(_ regex: NSRegularExpression, _ text: String) -> String? {
        let ns = text as NSString
        let range = NSRange(location: 0, length: ns.length)
        guard let m = regex.firstMatch(in: text, range: range),
              let r = Range(m.range(at: 1), in: text) else { return nil }
        return String(text[r])
    }

    // MARK: - Errors

    enum ExtractionError: LocalizedError {
        case invalidImage
        case noTextFound

        var errorDescription: String? {
            switch self {
            case .invalidImage: return "Could not process image."
            case .noTextFound: return "No text found in receipt."
            }
        }
    }
}

// MARK: - Date Formatter Cache

private final class DateFormatterCache {
    static let shared = DateFormatterCache()
    let formatter: DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = "MM/dd/yyyy"
        return f
    }()
}

// MARK: - Receipt Data Model

struct ReceiptData {
    var storeName: String?
    var date: Date?
    var total: Double?
    var items: [String] = []

    var expectedItemCount: Int?
    var cashierNumber: String?
    var registerNumber: String?
    var transactionNumber: String?
    var memberID: String?
    
    // Detailed line items with quantity and price info
    var detailedItems: [DetailedLineItem] = []
}

// MARK: - Detailed Line Item Model

/// Represents a line item with detailed pricing information
struct DetailedLineItem {
    let name: String
    let quantity: Int
    let unitPrice: Double?
    let totalPrice: Double?
    
    init(name: String, quantity: Int = 1, unitPrice: Double? = nil, totalPrice: Double? = nil) {
        self.name = name
        self.quantity = quantity
        self.unitPrice = unitPrice
        self.totalPrice = totalPrice
    }
    
    var displayString: String {
        var result = name
        if quantity > 1 {
            result += " (x\(quantity))"
        }
        if let price = totalPrice ?? unitPrice {
            result += " $\(String(format: "%.2f", price))"
        }
        return result
    }
    
    /// Effective price for this line item
    var effectivePrice: Double? {
        if let total = totalPrice {
            return total
        } else if let unit = unitPrice {
            return unit * Double(quantity)
        }
        return nil
    }
}
