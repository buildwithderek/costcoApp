//
//  ExportFile.swift
//  L1 Demo
//
//  Created by Derek Punaro on 12/14/25.
//

import Foundation

struct ExportFile: Identifiable {
    let id = UUID()
    let url: URL
}
