//
//  CSVPreviewView.swift
//  L1 Demo
//
//  CSV preview before export with table display
//  Updated: Comprehensive debugging for export issues
//

import SwiftUI

// MARK: - CSV Debug Logger

/// Centralized logging for CSV export debugging
enum CSVDebugLogger {
    static var isEnabled = true
    
    static func log(_ message: String, file: String = #file, line: Int = #line, function: String = #function) {
        guard isEnabled else { return }
        let fileName = (file as NSString).lastPathComponent
        let timestamp = ISO8601DateFormatter().string(from: Date())
        print("📊 [\(timestamp)] [\(fileName):\(line)] \(function) → \(message)")
    }
    
    static func logError(_ message: String, error: Error? = nil, file: String = #file, line: Int = #line) {
        let fileName = (file as NSString).lastPathComponent
        let timestamp = ISO8601DateFormatter().string(from: Date())
        var fullMessage = "❌ [\(timestamp)] [\(fileName):\(line)] ERROR: \(message)"
        if let error = error {
            fullMessage += "\n   └─ Underlying error: \(error.localizedDescription)"
        }
        print(fullMessage)
    }
    
    static func logFileInfo(url: URL, file: String = #file, line: Int = #line) {
        let fm = FileManager.default
        let fileName = (file as NSString).lastPathComponent
        let timestamp = ISO8601DateFormatter().string(from: Date())
        
        var info = "📁 [\(timestamp)] [\(fileName):\(line)] File Info:"
        info += "\n   ├─ URL: \(url.absoluteString)"
        info += "\n   ├─ Path: \(url.path)"
        info += "\n   ├─ Exists: \(fm.fileExists(atPath: url.path))"
        info += "\n   ├─ Readable: \(fm.isReadableFile(atPath: url.path))"
        
        if let attrs = try? fm.attributesOfItem(atPath: url.path) {
            let size = attrs[.size] as? Int64 ?? 0
            let created = attrs[.creationDate] as? Date
            let modified = attrs[.modificationDate] as? Date
            info += "\n   ├─ Size: \(size) bytes"
            if let created = created {
                info += "\n   ├─ Created: \(created)"
            }
            if let modified = modified {
                info += "\n   └─ Modified: \(modified)"
            }
        } else {
            info += "\n   └─ Attributes: Unable to read"
        }
        
        print(info)
    }
}

// MARK: - CSV Preview View

/// Shows a preview of CSV data before exporting
struct CSVPreviewView: View {
    let csvURL: URL
    let onExport: () -> Void
    let onCancel: () -> Void
    
    @State private var headers: [String] = []
    @State private var rows: [[String]] = []
    @State private var parseError: String?
    @State private var totalRowCount: Int = 0
    @State private var isLoading = true
    @State private var debugInfo: String = ""
    @State private var detailedDebugLog: [String] = []
    @State private var showDebugPanel = false
    
    private let previewLimit = 50
    
    var body: some View {
        NavigationStack {
            content
                .navigationTitle("Export Preview")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("Cancel", action: onCancel)
                    }
                    ToolbarItem(placement: .confirmationAction) {
                        Button {
                            CSVDebugLogger.log("User tapped Export button")
                            onExport()
                        } label: {
                            Label("Export", systemImage: "square.and.arrow.up")
                        }
                        .disabled(isLoading || parseError != nil)
                    }
                }
                .toolbar {
                    // Debug toggle in toolbar
                    ToolbarItem(placement: .bottomBar) {
                        Button {
                            showDebugPanel.toggle()
                        } label: {
                            Label("Debug", systemImage: showDebugPanel ? "ladybug.fill" : "ladybug")
                                .foregroundColor(showDebugPanel ? .orange : .secondary)
                        }
                    }
                }
                .task {
                    await loadCSV()
                }
        }
    }
    
    @ViewBuilder
    private var content: some View {
        VStack(spacing: 0) {
            if isLoading {
                loadingView
            } else if let error = parseError {
                errorView(error)
            } else if headers.isEmpty {
                errorView("No data found in CSV")
            } else {
                VStack(spacing: 0) {
                    summaryBar
                    csvTable
                }
            }
            
            // Debug panel (collapsible)
            if showDebugPanel {
                debugPanel
            }
        }
    }
    
    private var loadingView: some View {
        VStack(spacing: 16) {
            ProgressView()
                .scaleEffect(1.2)
            Text("Loading preview...")
                .foregroundColor(.secondary)
            Text("Path: \(csvURL.lastPathComponent)")
                .font(.caption2)
                .foregroundColor(.gray)
        }
    }
    
    private var summaryBar: some View {
        HStack {
            Label("\(totalRowCount) row\(totalRowCount == 1 ? "" : "s")", systemImage: "tablecells")
            Spacer()
            if totalRowCount > previewLimit {
                Text("Showing first \(previewLimit)")
                    .foregroundColor(.secondary)
            }
        }
        .font(.caption)
        .padding(.horizontal)
        .padding(.vertical, 8)
        .background(Color(.secondarySystemGroupedBackground))
    }
    
    private var csvTable: some View {
        ScrollView([.horizontal, .vertical]) {
            LazyVStack(alignment: .leading, spacing: 0, pinnedViews: [.sectionHeaders]) {
                Section {
                    ForEach(rows.indices, id: \.self) { rowIndex in
                        rowView(for: rowIndex)
                    }
                } header: {
                    headerRow
                }
            }
        }
    }
    
    private func rowView(for rowIndex: Int) -> some View {
        HStack(spacing: 0) {
            ForEach(0..<headers.count, id: \.self) { colIndex in
                let value = colIndex < rows[rowIndex].count ? rows[rowIndex][colIndex] : ""
                Text(value)
                    .font(.system(.caption, design: .monospaced))
                    .lineLimit(2)
                    .frame(width: columnWidth(for: colIndex), alignment: .leading)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 6)
                    .background(rowIndex % 2 == 0 ? Color.clear : Color(.systemGray6))
            }
        }
    }
    
    private var headerRow: some View {
        HStack(spacing: 0) {
            ForEach(headers.indices, id: \.self) { index in
                Text(headers[index])
                    .font(.system(.caption, design: .monospaced))
                    .fontWeight(.semibold)
                    .lineLimit(1)
                    .frame(width: columnWidth(for: index), alignment: .leading)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 8)
            }
        }
        .background(Color(.systemGray4))
    }
    
    private func errorView(_ error: String) -> some View {
        ScrollView {
            VStack(spacing: 16) {
                Image(systemName: "exclamationmark.triangle")
                    .font(.system(size: 40))
                    .foregroundColor(.orange)
                
                Text("Failed to load preview")
                    .font(.headline)
                
                Text(error)
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                
                // Debug info for troubleshooting
                if !debugInfo.isEmpty {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Debug Info:")
                            .font(.caption)
                            .fontWeight(.semibold)
                        Text(debugInfo)
                            .font(.caption2)
                            .foregroundColor(.gray)
                            .multilineTextAlignment(.leading)
                    }
                    .padding(.horizontal)
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                
                // Still allow export even if preview fails
                Button {
                    CSVDebugLogger.log("User tapped 'Export Anyway' after preview failure")
                    onExport()
                } label: {
                    Text("Export Anyway")
                        .font(.subheadline)
                        .foregroundColor(.blue)
                }
                .padding(.top, 8)
                
                // Copy debug info button
                Button {
                    let fullDebug = detailedDebugLog.joined(separator: "\n")
                    UIPasteboard.general.string = fullDebug
                } label: {
                    Label("Copy Debug Log", systemImage: "doc.on.doc")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            .padding()
        }
    }
    
    // MARK: - Debug Panel
    
    private var debugPanel: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("Debug Log")
                    .font(.caption)
                    .fontWeight(.semibold)
                Spacer()
                Button {
                    UIPasteboard.general.string = detailedDebugLog.joined(separator: "\n")
                } label: {
                    Image(systemName: "doc.on.doc")
                        .font(.caption)
                }
            }
            
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 2) {
                    ForEach(detailedDebugLog.indices, id: \.self) { index in
                        Text(detailedDebugLog[index])
                            .font(.system(.caption2, design: .monospaced))
                            .foregroundColor(detailedDebugLog[index].contains("❌") ? .red :
                                                detailedDebugLog[index].contains("✅") ? .green : .primary)
                    }
                }
            }
            .frame(height: 150)
        }
        .padding()
        .background(Color(.systemGray6))
    }
    
    // MARK: - Helpers
    
    private func columnWidth(for index: Int) -> CGFloat {
        guard index < headers.count else { return 100 }
        
        let header = headers[index].lowercased()
        
        if header.contains("name") || header.contains("item") {
            return 150
        } else if header.contains("date") {
            return 100
        } else if header.contains("total") || header.contains("cost") {
            return 80
        } else {
            return 90
        }
    }
    
    private func addDebugLog(_ message: String) {
        let timestamp = DateFormatter.localizedString(from: Date(), dateStyle: .none, timeStyle: .medium)
        detailedDebugLog.append("[\(timestamp)] \(message)")
    }
    
    private func loadCSV() async {
        addDebugLog("🚀 Starting CSV load process")
        addDebugLog("📍 URL: \(csvURL.absoluteString)")
        addDebugLog("📂 Path: \(csvURL.path)")
        
        CSVDebugLogger.log("Starting CSV load for: \(csvURL.lastPathComponent)")
        CSVDebugLogger.logFileInfo(url: csvURL)
        
        // Check if file exists immediately
        let immediateExists = FileManager.default.fileExists(atPath: csvURL.path)
        addDebugLog("📋 File exists (immediate check): \(immediateExists)")
        
        // Wait for file system to sync
        addDebugLog("⏳ Waiting 200ms for filesystem sync...")
        try? await Task.sleep(nanoseconds: 200_000_000)
        
        // Retry logic for file access
        var attempts = 0
        let maxAttempts = 5  // Increased from 3
        let retryDelayNs: UInt64 = 150_000_000  // 150ms between retries
        
        while attempts < maxAttempts {
            attempts += 1
            addDebugLog("🔄 Attempt \(attempts)/\(maxAttempts)")
            
            let fileExists = FileManager.default.fileExists(atPath: csvURL.path)
            addDebugLog("   File exists: \(fileExists)")
            
            if fileExists {
                // Check if readable
                let isReadable = FileManager.default.isReadableFile(atPath: csvURL.path)
                addDebugLog("   Readable: \(isReadable)")
                
                // Check file size
                if let attrs = try? FileManager.default.attributesOfItem(atPath: csvURL.path),
                   let size = attrs[.size] as? Int64 {
                    addDebugLog("   Size: \(size) bytes")
                    
                    if size == 0 {
                        addDebugLog("   ⚠️ File is empty, waiting...")
                        try? await Task.sleep(nanoseconds: retryDelayNs)
                        continue
                    }
                }
                
                CSVDebugLogger.log("File found on attempt \(attempts)")
                addDebugLog("✅ File validated, parsing...")
                
                await MainActor.run {
                    parseCSV()
                    isLoading = false
                }
                return
            }
            
            // List temp directory contents for debugging
            if attempts == 1 {
                let tempDir = FileManager.default.temporaryDirectory
                addDebugLog("📂 Temp directory contents:")
                if let contents = try? FileManager.default.contentsOfDirectory(atPath: tempDir.path) {
                    for item in contents.prefix(10) {
                        addDebugLog("   - \(item)")
                    }
                    if contents.count > 10 {
                        addDebugLog("   ... and \(contents.count - 10) more files")
                    }
                } else {
                    addDebugLog("   ❌ Could not list directory")
                }
            }
            
            // Wait before retry
            addDebugLog("   Waiting \(Int(retryDelayNs / 1_000_000))ms before retry...")
            try? await Task.sleep(nanoseconds: retryDelayNs)
        }
        
        // File still not found after retries
        CSVDebugLogger.logError("CSV file not found after \(maxAttempts) attempts", error: nil)
        addDebugLog("❌ File not found after \(maxAttempts) attempts")
        
        await MainActor.run {
            parseError = "CSV file not found after \(maxAttempts) attempts"
            debugInfo = buildDebugInfo()
            isLoading = false
        }
    }
    
    private func buildDebugInfo() -> String {
        var info: [String] = []
        info.append("File: \(csvURL.lastPathComponent)")
        info.append("Full path: \(csvURL.path)")
        info.append("Scheme: \(csvURL.scheme ?? "none")")
        
        let fm = FileManager.default
        info.append("Exists: \(fm.fileExists(atPath: csvURL.path))")
        info.append("Readable: \(fm.isReadableFile(atPath: csvURL.path))")
        
        // Check parent directory
        let parentDir = csvURL.deletingLastPathComponent()
        info.append("Parent exists: \(fm.fileExists(atPath: parentDir.path))")
        
        return info.joined(separator: "\n")
    }
    
    private func parseCSV() {
        addDebugLog("📝 Starting CSV parse")
        
        let fileManager = FileManager.default
        
        guard fileManager.fileExists(atPath: csvURL.path) else {
            parseError = "CSV file not found"
            debugInfo = "Expected at: \(csvURL.path)"
            addDebugLog("❌ File not found during parse")
            CSVDebugLogger.logError("CSV file not found during parse")
            return
        }
        
        guard fileManager.isReadableFile(atPath: csvURL.path) else {
            parseError = "CSV file is not readable"
            debugInfo = "Path: \(csvURL.lastPathComponent)"
            addDebugLog("❌ File not readable")
            CSVDebugLogger.logError("CSV file not readable")
            return
        }
        
        do {
            addDebugLog("📖 Reading file contents...")
            let content = try String(contentsOf: csvURL, encoding: .utf8)
            addDebugLog("✅ Read \(content.count) characters")
            
            guard !content.isEmpty else {
                parseError = "CSV file is empty"
                debugInfo = "File size: 0 bytes"
                addDebugLog("❌ File is empty")
                return
            }
            
            let lines = content.components(separatedBy: .newlines).filter { !$0.isEmpty }
            addDebugLog("📊 Found \(lines.count) non-empty lines")
            
            guard let headerLine = lines.first else {
                parseError = "CSV file has no header row"
                debugInfo = "Total lines: \(lines.count)"
                addDebugLog("❌ No header row")
                return
            }
            
            headers = parseCSVLine(headerLine)
            addDebugLog("📋 Parsed \(headers.count) headers: \(headers.joined(separator: ", "))")
            
            totalRowCount = max(0, lines.count - 1)
            addDebugLog("📈 Total data rows: \(totalRowCount)")
            
            // Load preview rows
            let dataLines = Array(lines.dropFirst().prefix(previewLimit))
            rows = dataLines.map { parseCSVLine($0) }
            addDebugLog("✅ Loaded \(rows.count) preview rows")
            
            CSVDebugLogger.log("CSV parsed successfully: \(headers.count) columns, \(totalRowCount) rows")
            
        } catch {
            parseError = "Failed to read file: \(error.localizedDescription)"
            debugInfo = "File: \(csvURL.lastPathComponent)"
            addDebugLog("❌ Parse error: \(error.localizedDescription)")
            CSVDebugLogger.logError("CSV parse error", error: error)
        }
    }
    
    /// Split CSV content into record lines, honoring quoted newlines.
    private func splitCSVRecords(_ content: String) -> [String] {
        var records: [String] = []
        var current = ""
        var inQuotes = false
        
        var i = content.startIndex
        while i < content.endIndex {
            let ch = content[i]
            
            if ch == "\"" {
                // Handle escaped quote inside quotes: ""
                let next = content.index(after: i)
                if inQuotes, next < content.endIndex, content[next] == "\"" {
                    current.append("\"")
                    i = content.index(after: next)
                    continue
                } else {
                    inQuotes.toggle()
                    // Keep the quote out of the final output; parser will handle structure
                    i = content.index(after: i)
                    continue
                }
            }
            
            // Newline ends a record only if we're not inside quotes
            if (ch == "\n" || ch == "\r"), !inQuotes {
                // Handle CRLF: treat \r\n as one newline
                if ch == "\r" {
                    let next = content.index(after: i)
                    if next < content.endIndex, content[next] == "\n" {
                        i = content.index(after: next)
                    } else {
                        i = content.index(after: i)
                    }
                } else {
                    i = content.index(after: i)
                }
                
                if !current.isEmpty {
                    records.append(current)
                    current = ""
                }
                continue
            }
            
            current.append(ch)
            i = content.index(after: i)
        }
        
        if !current.isEmpty {
            records.append(current)
        }
        
        return records
    }
    
    /// Parse a single CSV record line into fields (handles commas + quotes + escaped quotes).
    private func parseCSVLine(_ line: String) -> [String] {
        var fields: [String] = []
        var field = ""
        var inQuotes = false
        
        var i = line.startIndex
        while i < line.endIndex {
            let ch = line[i]
            
            if ch == "\"" {
                let next = line.index(after: i)
                if inQuotes, next < line.endIndex, line[next] == "\"" {
                    // Escaped quote -> literal quote
                    field.append("\"")
                    i = line.index(after: next)
                    continue
                } else {
                    // Toggle quoted state; don't include the quote char itself
                    inQuotes.toggle()
                    i = line.index(after: i)
                    continue
                }
            }
            
            if ch == "," && !inQuotes {
                fields.append(field.trimmingCharacters(in: .whitespaces))
                field = ""
                i = line.index(after: i)
                continue
            }
            
            field.append(ch)
            i = line.index(after: i)
        }
        
        fields.append(field.trimmingCharacters(in: .whitespaces))
        return fields
    }
}

// MARK: - CSV Export Flow Modifier

/// Manages the preview + export flow with debugging
struct CSVExportFlow: ViewModifier {
    @Binding var csvURL: URL?
    @Binding var showPreview: Bool
    @Binding var showShareSheet: Bool
    
    func body(content: Content) -> some View {
        content
            .sheet(isPresented: $showPreview) {
                if let url = csvURL {
                    CSVPreviewView(
                        csvURL: url,
                        onExport: {
                            CSVDebugLogger.log("Export flow: Preview dismissed, showing share sheet")
                            showPreview = false
                            // Delay to allow sheet dismissal animation
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
                                showShareSheet = true
                            }
                        },
                        onCancel: {
                            CSVDebugLogger.log("Export flow: User cancelled preview")
                            showPreview = false
                        }
                    )
                } else {
                    // Fallback if URL is nil - this is the problem case!
                    VStack(spacing: 16) {
                        Image(systemName: "exclamationmark.triangle")
                            .font(.system(size: 40))
                            .foregroundColor(.orange)
                        Text("No CSV file to preview")
                            .font(.headline)
                        Text("The export file URL is nil")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        Text("This usually means the export failed before creating the file.")
                            .font(.caption2)
                            .foregroundColor(.gray)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal)
                        Button("Close") {
                            CSVDebugLogger.logError("Preview shown with nil URL")
                            showPreview = false
                        }
                    }
                    .padding()
                    .onAppear {
                        CSVDebugLogger.logError("CSVExportFlow: csvURL is nil when showing preview!")
                    }
                }
            }
            .sheet(isPresented: $showShareSheet) {
                if let url = csvURL {
                    ShareSheet(activityItems: [url])
                        .onAppear {
                            CSVDebugLogger.log("Share sheet appeared with URL: \(url.lastPathComponent)")
                        }
                }
            }
    }
}

extension View {
    func csvExportFlow(
        csvURL: Binding<URL?>,
        showPreview: Binding<Bool>,
        showShareSheet: Binding<Bool>
    ) -> some View {
        modifier(CSVExportFlow(
            csvURL: csvURL,
            showPreview: showPreview,
            showShareSheet: showShareSheet
        ))
    }
}

// MARK: - Preview

#Preview {
    CSVPreviewView(
        csvURL: URL(fileURLWithPath: "/tmp/test.csv"),
        onExport: {},
        onCancel: {}
    )
}
